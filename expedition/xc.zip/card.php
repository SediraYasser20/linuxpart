<?php
/* Copyright (C) 2003-2008	Rodolphe Quiedeville	<rodolphe@quiedeville.org>
 * Copyright (C) 2005-2016	Laurent Destailleur		<eldy@users.sourceforge.net>
 * Copyright (C) 2005		Simon TOSSER			<simon@kornog-computing.com>
 * Copyright (C) 2005-2012	Regis Houssin			<regis.houssin@inodbox.com>
 * Copyright (C) 2011-2017	Juanjo Menent			<jmenent@2byte.es>
 * Copyright (C) 2013       Florian Henry		  	<florian.henry@open-concept.pro>
 * Copyright (C) 2013       Marcos GarcÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­a           <marcosgdf@gmail.com>
 * Copyright (C) 2014		Cedric GROSS			<c.gross@kreiz-it.fr>
 * Copyright (C) 2014-2017	Francis Appels			<francis.appels@yahoo.com>
 * Copyright (C) 2015		Claudio Aschieri		<c.aschieri@19.coop>
 * Copyright (C) 2016-2018	Ferran Marcet			<fmarcet@2byte.es>
 * Copyright (C) 2016		Yasser CarreÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â³n			<yacasia@gmail.com>
 * Copyright (C) 2018-2024  FrÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â©dÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â©ric France         <frederic.france@free.fr>
 * Copyright (C) 2020       Lenin Rivas         	<lenin@leninrivas.com>
 * Copyright (C) 2022       Josep LluÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­s Amador      <joseplluis@lliuretic.cat>
 * Copyright (C) 2024		MDW						<mdeweerd@users.noreply.github.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *	\file       htdocs/expedition/card.php
 *	\ingroup    expedition
 *	\brief      Card of a shipment
 */

// Load Dolibarr environment
require '../main.inc.php';

if (!function_exists('getBaseSerialNumberPart')) {
    /**
     * Extracts the base part of a serial number or MO reference string.
     * The base part is defined as the substring before the third hyphen,
     * or the whole string if fewer than three hyphens exist.
     *
     * @param string \$serial_string The input serial number or MO reference.
     * @return string The base part of the string.
     */
    function getBaseSerialNumberPart($serial_string) {
        $hyphen_count = 0;
        $cut_off_position = strlen($serial_string); // Default to full string

        for ($i = 0; $i < strlen($serial_string); $i++) {
            if ($serial_string[$i] == '-') {
                $hyphen_count++;
                if ($hyphen_count == 3) {
                    $cut_off_position = $i;
                    break;
                }
            }
        }
        return substr($serial_string, 0, $cut_off_position);
    }
}

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
require_once DOL_DOCUMENT_ROOT.'/expedition/class/expedition.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/html.formproduct.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/sendings.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/expedition/modules_expedition.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/doleditor.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/stock/class/entrepot.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/stock/class/productlot.class.php';
require_once DOL_DOCUMENT_ROOT.'/commande/class/commande.class.php';
if (isModEnabled("product") || isModEnabled("service")) {
	require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
}
if (isModEnabled("propal")) {
	require_once DOL_DOCUMENT_ROOT.'/comm/propal/class/propal.class.php';
}
if (isModEnabled('productbatch')) {
	require_once DOL_DOCUMENT_ROOT.'/product/class/productbatch.class.php';
}
if (isModEnabled('project')) {
	require_once DOL_DOCUMENT_ROOT.'/projet/class/project.class.php';
	require_once DOL_DOCUMENT_ROOT.'/core/class/html.formprojet.class.php';
}

/**
 * @var Conf $conf
 * @var DoliDB $db
 * @var HookManager $hookmanager
 * @var Translate $langs
 * @var User $user
 */

// Load translation files required by the page
$langs->loadLangs(array("sendings", "companies", "bills", 'deliveries', 'orders', 'stocks', 'other', 'propal', 'productbatch'));

if (isModEnabled('incoterm')) {
	$langs->load('incoterm');
}
if (isModEnabled('productbatch')) {
	$langs->load('productbatch');
}

$origin = GETPOST('origin', 'alpha') ? GETPOST('origin', 'alpha') : 'expedition'; // Example: commande, propal
$origin_id = GETPOSTINT('id') ? GETPOSTINT('id') : '';
$id = $origin_id;
if (empty($origin_id)) {
	$origin_id  = GETPOSTINT('origin_id'); // Id of order or propal
}
if (empty($origin_id)) {
	$origin_id  = GETPOSTINT('object_id'); // Id of order or propal
}
$ref = GETPOST('ref', 'alpha');
$line_id = GETPOSTINT('lineid');
$facid = GETPOSTINT('facid');

$action		= GETPOST('action', 'alpha');
$confirm	= GETPOST('confirm', 'alpha');
$cancel = GETPOST('cancel', 'alpha');

//PDF
$hidedetails = (GETPOSTINT('hidedetails') ? GETPOSTINT('hidedetails') : (getDolGlobalString('MAIN_GENERATE_DOCUMENTS_HIDE_DETAILS') ? 1 : 0));
$hidedesc = (GETPOSTINT('hidedesc') ? GETPOSTINT('hidedesc') : (getDolGlobalString('MAIN_GENERATE_DOCUMENTS_HIDE_DESC') ? 1 : 0));
$hideref = (GETPOSTINT('hideref') ? GETPOSTINT('hideref') : (getDolGlobalString('MAIN_GENERATE_DOCUMENTS_HIDE_REF') ? 1 : 0));

$object = new Expedition($db);
$objectorder = new Commande($db);
$extrafields = new ExtraFields($db);

// fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);
$extrafields->fetch_name_optionals_label($object->table_element_line);
$extrafields->fetch_name_optionals_label($objectorder->table_element_line);

// Load object. Make an object->fetch
include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be 'include', not 'include_once'

// Initialize a technical object to manage hooks of page. Note that conf->hooks_modules contains an array of hook context
$hookmanager->initHooks(array('expeditioncard', 'globalcard'));

$date_delivery = dol_mktime(GETPOSTINT('date_deliveryhour'), GETPOSTINT('date_deliverymin'), 0, GETPOSTINT('date_deliverymonth'), GETPOSTINT('date_deliveryday'), GETPOSTINT('date_deliveryyear'));

$date_shipping = dol_mktime(GETPOSTINT('date_shippinghour'), GETPOSTINT('date_shippingmin'), 0, GETPOSTINT('date_shippingmonth'), GETPOSTINT('date_shippingday'), GETPOSTINT('date_shippingyear'));

if ($id > 0 || !empty($ref)) {
	$object->fetch($id, $ref);
	$object->fetch_thirdparty();
}

// Security check
$socid = '';
if ($user->socid) {
	$socid = $user->socid;
}

$result = restrictedArea($user, 'expedition', $object->id, '');

$permissiondellink = $user->hasRight('expedition', 'delivery', 'creer'); // Used by the include of actions_dellink.inc.php
$permissiontoadd = $user->hasRight('expedition', 'creer');

$upload_dir = $conf->expedition->dir_output.'/sending';

$editColspan = 0;
$objectsrc = null;
$typeobject = null;


/*
 * Actions
 */

$error = 0;
$parameters = array();
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) {
	setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');
}

if (empty($reshook)) {
	if ($cancel) {
		if ($origin && $origin_id > 0) {
			if ($origin == 'commande') {
				header("Location: ".DOL_URL_ROOT.'/expedition/shipment.php?id='.((int) $origin_id));
				exit;
			}
		} else {
			$action = '';
			$object->fetch($id); // show shipment also after canceling modification
		}
	}

	include DOL_DOCUMENT_ROOT.'/core/actions_dellink.inc.php'; // Must be 'include', not 'include_once'

	// Actions to build doc
	include DOL_DOCUMENT_ROOT.'/core/actions_builddoc.inc.php';

	// Back to draft
	if ($action == 'setdraft' && $permissiontoadd) {
		$object->fetch($id);
		$result = $object->setDraft($user, 0);
		if ($result < 0) {
			setEventMessages($object->error, $object->errors, 'errors');
		} else {
			header("Location: ".$_SERVER['PHP_SELF']."?id=".$object->id);
			exit;
		}
	}
	// Reopen
	if ($action == 'reopen' && $permissiontoadd) {
		$object->fetch($id);
		$result = $object->reOpen();
		if ($result < 0) {
			setEventMessages($object->error, $object->errors, 'errors');
		} else {
			header("Location: ".$_SERVER['PHP_SELF']."?id=".$object->id);
			exit;
		}
	}

	// Set incoterm
	if ($action == 'set_incoterms' && isModEnabled('incoterm') && $permissiontoadd) {
		$result = $object->setIncoterms(GETPOSTINT('incoterm_id'), GETPOST('location_incoterms'));
	}

	if ($action == 'setref_customer' && $permissiontoadd) {
		$result = $object->fetch($id);
		if ($result < 0) {
			setEventMessages($object->error, $object->errors, 'errors');
		}

		$result = $object->setValueFrom('ref_customer', GETPOST('ref_customer', 'alpha'), '', null, 'text', '', $user, 'SHIPMENT_MODIFY');
		if ($result < 0) {
			setEventMessages($object->error, $object->errors, 'errors');
			$action = 'editref_customer';
		} else {
			header("Location: ".$_SERVER['PHP_SELF']."?id=".$object->id);
			exit;
		}
	}

	if ($action == 'update_extras' && $permissiontoadd) {
		$object->oldcopy = dol_clone($object, 2);
		$attribute_name = GETPOST('attribute', 'restricthtml');

		// Fill array 'array_options' with data from update form
		$ret = $extrafields->setOptionalsFromPost(null, $object, $attribute_name);
		if ($ret < 0) {
			$error++;
		}

		if (!$error) {
			// Actions on extra fields
			$result = $object->updateExtraField($attribute_name, 'SHIPMENT_MODIFY');
			if ($result < 0) {
				setEventMessages($object->error, $object->errors, 'errors');
				$error++;
			}
		}

		if ($error) {
			$action = 'edit_extras';
		}
	}

	// Create shipment
	// Create shipment
// Create shipment
if ($action == 'add' && $permissiontoadd) {
    $db->begin();

    $object->note = GETPOST('note', 'restricthtml');
    $object->note_private = GETPOST('note', 'restricthtml');
    
    // Ensure $origin is correctly sourced
    $origin_for_add = GETPOST('origin', 'alpha');
    if (empty($origin_for_add)) {
        setEventMessages($langs->trans("ErrorMissingOriginForShipmentCreation"), null, 'errors');
        $error++;
    } else {
        $object->origin = $origin_for_add;
    }

    $object->origin_id = GETPOSTINT('origin_id');
    $object->fk_project = GETPOSTINT('projectid');
    $object->weight = GETPOSTINT('weight') == '' ? "NULL" : GETPOSTINT('weight');
    $object->sizeH = GETPOSTINT('sizeH') == '' ? "NULL" : GETPOSTINT('sizeH');
    $object->sizeW = GETPOSTINT('sizeW') == '' ? "NULL" : GETPOSTINT('sizeW');
    $object->sizeS = GETPOSTINT('sizeS') == '' ? "NULL" : GETPOSTINT('sizeS');
    $object->size_units = GETPOSTINT('size_units');
    $object->weight_units = GETPOSTINT('weight_units');

    $product_for_mo_details = new Product($db);

    // Process origin document
    if (!$error) {
        $classname = ucfirst($object->origin);
        if (class_exists($classname)) {
            $objectsrc = new $classname($db);
            '@phan-var-force Facture|Commande $objectsrc';
            if (!$objectsrc->fetch($object->origin_id)) {
                setEventMessages($langs->trans("ErrorFailedToFetchOriginObject", $object->origin, $object->origin_id), null, 'errors');
                $error++;
            }
        } else {
            setEventMessages($langs->trans("ErrorUnknownOriginClass", $classname), null, 'errors');
            $error++;
        }
    }
    
    if (!$error) {
        $object->socid = $objectsrc->socid;
        $object->ref_customer = GETPOST('ref_customer', 'alpha');
        $object->model_pdf = GETPOST('model');
        $object->date_delivery = $date_delivery;
        $object->date_shipping = $date_shipping;
        $object->fk_delivery_address = $objectsrc->fk_delivery_address;
        $object->shipping_method_id = GETPOSTINT('shipping_method_id');
        $object->tracking_number = GETPOST('tracking_number', 'alpha');
        $object->note_private = GETPOST('note_private', 'restricthtml');
        $object->note_public = GETPOST('note_public', 'restricthtml');
        $object->fk_incoterms = GETPOSTINT('incoterm_id');
        $object->location_incoterms = GETPOST('location_incoterms', 'alpha');

        $batch_line = array();
        $stockLine = array();
        $array_options = array();

        $num = count($objectsrc->lines);
        $totalqty = 0;
        $product_batch_used_for_serial_check = array();

        // Process each order line
        for ($i = 0; $i < $num; $i++) {
            $current_order_line = $objectsrc->lines[$i];
            $idl_name = "idl".$i; 
            $original_line_id = GETPOSTINT($idl_name); 

            $sub_qty_details = array(); 
            $subtotal_qty_for_line = 0; 

            $qty_input_prefix = "qtyl".$i;
            $stock_loc_input_prefix = "entl".$i;

            $effective_fk_product_for_line = $current_order_line->fk_product;
            $product_management_mode = 0; 
            $mo_product_id_override = 483;
            $product_ref_for_error_msg = $current_order_line->ref;

            // FIXED: Correct MO detection syntax
            $is_mo_line = false;
            if (empty($current_order_line->fk_product)) {
                $is_mo_line = (strpos($current_order_line->description, 'Costum-PC' ) === 0 || strpos($desc, 'OF') === 0) && 
                              (strpos($current_order_line->description, '(Fabrication)') !== false);
            }

            if ($is_mo_line) {
                if ($product_for_mo_details->fetch($mo_product_id_override) > 0) {
                    $effective_fk_product_for_line = $mo_product_id_override;
                    $product_management_mode = $product_for_mo_details->status_batch;
                    $product_ref_for_error_msg = $product_for_mo_details->ref;
                } else {
                    setEventMessages("Error: Product with rowid ".$mo_product_id_override." for MO line processing not found.", null, 'errors');
                    $error++; 
                }
            } elseif (!empty($current_order_line->fk_product)) {
                $temp_regular_prod = new Product($db);
                if ($temp_regular_prod->fetch($current_order_line->fk_product) > 0) {
                    $product_management_mode = $temp_regular_prod->status_batch;
                    $product_ref_for_error_msg = $temp_regular_prod->ref;
                } else {
                    setEventMessages("Error: Product ".$current_order_line->fk_product." (Order Line ID: ".$current_order_line->id.") not found during quantity processing.", null, 'errors');
                    $error++;
                }
            }
            
            if ($error) break; 

            // Batch/Serial managed products
            if (isModEnabled('productbatch') && $product_management_mode > 0) {
                $k = 0;
                $current_qty_field_name = $qty_input_prefix."_".$k;

                // Loop is driven by presence of quantity fields
                while (GETPOSTISSET($current_qty_field_name)) {
                    $qty_val = price2num(GETPOST($current_qty_field_name, 'alpha'), 'MS');
                    $batch_text_val = GETPOST("batch_text_l".$i."_".$k, 'alpha');
                    $warehouse_id_for_batch = GETPOSTINT("entl".$i."_".$k);
                    $batch_id_val = 0;

                    if ($qty_val > 0) {
                        if (empty($batch_text_val)) {
							// If product is managed by serial, empty serial means we don't ship this unit. Just ignore line.
							if ($product_management_mode == 2)
							{
								$k++;
								$current_qty_field_name = $qty_input_prefix."_".$k;
								continue;
							}
                            setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv("Batch")), null, 'errors');
                            $error++; break 2;
                        }

                        // Find batch ID from text, product, and warehouse
                        $sql_find_batch = "SELECT t.rowid FROM ".MAIN_DB_PREFIX."product_batch as t INNER JOIN ".MAIN_DB_PREFIX."product_stock as ps ON t.fk_product_stock = ps.rowid WHERE t.batch = '".$db->escape($batch_text_val)."' AND ps.fk_product = ".((int) $effective_fk_product_for_line);
                        if ($warehouse_id_for_batch > 0) {
                            $sql_find_batch .= " AND ps.fk_entrepot = ".$warehouse_id_for_batch;
                        }
                        $resql_find_batch = $db->query($sql_find_batch);
                        if ($resql_find_batch) {
                            if ($db->num_rows($resql_find_batch) > 0) {
                                $obj_batch_found = $db->fetch_object($resql_find_batch);
                                $batch_id_val = $obj_batch_found->rowid;
                            } else {
                                $wh_ref = '';
                                if ($warehouse_id_for_batch > 0) {
                                    $tmpwh = new Entrepot($db);
                                    if ($tmpwh->fetch($warehouse_id_for_batch) > 0) $wh_ref = $tmpwh->ref;
                                }
                                setEventMessages("The batch/serial entered (".dol_escape_htmltag($batch_text_val).") does not exist for this product in the specified warehouse (".$wh_ref.").", null, 'errors');
                                $error++; break 2;
                            }
                        } else {
                            setEventMessages("Database error looking up batch/serial: ".$db->lasterror(), null, 'errors');
                            $error++; break 2;
                        }

                        // Now that we have $batch_id_val, the original logic can proceed.
                        if ($product_management_mode == 2) { // Serials
                            if ($qty_val > 1) {
                                setEventMessages($langs->trans("TooManyQtyForSerialNumber", $product_ref_for_error_msg), null, 'errors');
                                $error++; break 2;
                            }
                            $serial_key = $effective_fk_product_for_line . '_' . $batch_id_val;
                            if (in_array($serial_key, $product_batch_used_for_serial_check)) {
                                setEventMessages($langs->trans("SerialAlreadyUsed", $product_ref_for_error_msg), null, 'errors');
                                $error++; break 2;
                            }
                            $product_batch_used_for_serial_check[] = $serial_key;

                            if ($is_mo_line && $effective_fk_product_for_line == 483) {
                                $mo_ref_from_db = '';
                                if (!empty($current_order_line->fk_mrp_mo)) {
                                    $sql_mo_ref = "SELECT ref FROM ".MAIN_DB_PREFIX."mrp_mo WHERE rowid = ".((int) $current_order_line->fk_mrp_mo);
                                    $resql_mo_ref = $db->query($sql_mo_ref);
                                    if ($resql_mo_ref && $db->num_rows($resql_mo_ref) > 0) {
                                        $obj_mo_ref = $db->fetch_object($resql_mo_ref);
                                        $mo_ref_from_db = $obj_mo_ref->ref;
                                    } else {
                                        setEventMessages($langs->trans("ErrorMORecordNotFoundForFK", $current_order_line->fk_mrp_mo), null, 'errors');
                                        $error++; break 2;
                                    }
                                } else {
                                   $desc = trim($current_order_line->description);
                                    if (preg_match('/^(Costum-PC\S*|OF\S*)/', $desc, $matches_desc_mo)) {
                                        $mo_ref_from_db = $matches_desc_mo[1];
                                    } else {
                                        setEventMessages($langs->trans("ErrorMORefLinkOrDescMissing", $current_order_line->id), null, 'errors');
                                        $error++; break 2;
                                    }
                                }

                                $productbatch_entry = new Productbatch($db);
                                if ($batch_id_val > 0 && $productbatch_entry->fetch($batch_id_val) > 0) {
                                    $entered_serial = $productbatch_entry->batch;
                                    $base_mo_ref = getBaseSerialNumberPart($mo_ref_from_db);
                                    $base_entered_serial = getBaseSerialNumberPart($entered_serial);

                                    if ($base_mo_ref !== $base_entered_serial) {
                                        setEventMessages($langs->trans("ErrorSerialBaseDoesNotMatchMOBase", $entered_serial, $mo_ref_from_db), null, 'errors');
                                        $error++; break 2;
                                    } else {
                                        if (strlen($entered_serial) > strlen($base_entered_serial)) {
                                            $suffix_part = substr($entered_serial, strlen($base_entered_serial));
                                            if (!preg_match('/^-([1-9]\d*)$/', $suffix_part)) {
                                                setEventMessages($langs->trans("ErrorSerialSuffixInvalidFormat", $entered_serial, $base_entered_serial), null, 'errors');
                                                $error++; break 2;
                                            }
                                        }
                                    }
                                } else {
                                    setEventMessages($langs->trans("ErrorFailedToFetchBatchDetailsForID", $batch_id_val), null, 'errors');
                                    $error++; break 2;
                                }
                            }
                        }
                        $sub_qty_details[$k]['q'] = $qty_val;
                        $sub_qty_details[$k]['id_batch'] = $batch_id_val;
                        $subtotal_qty_for_line += $qty_val;
                    }
                    $k++;
                    $current_qty_field_name = $qty_input_prefix."_".$k;
                }
                if (!$error) {
                    $batch_line[$i]['detail'] = $sub_qty_details;
                    $batch_line[$i]['qty'] = $subtotal_qty_for_line;
                    $batch_line[$i]['ix_l'] = $original_line_id;
                    $batch_line[$i]['fk_product'] = $effective_fk_product_for_line;
                }
            }
            // Multiple stock locations
            elseif ($effective_fk_product_for_line > 0 && isModEnabled('stock') && GETPOSTISSET($stock_loc_input_prefix."_0")) {
                $k = 0;
                $current_stock_loc_field_name = $stock_loc_input_prefix."_".$k;
                $current_qty_field_name = $qty_input_prefix."_".$k;
                while (GETPOSTISSET($current_stock_loc_field_name)) {
                    $qty_val = price2num(GETPOST($current_qty_field_name, 'alpha'), 'MS');
                    if ($qty_val > 0) {
                        $stockLine[$i][$k]['qty'] = $qty_val;
                        $stockLine[$i][$k]['warehouse_id'] = GETPOSTINT($current_stock_loc_field_name);
                        $stockLine[$i][$k]['ix_l'] = $original_line_id;
                        // Store the effective product ID for later use
                        $stockLine[$i][$k]['fk_product'] = $effective_fk_product_for_line;
                        $subtotal_qty_for_line += $qty_val;
                    }
                    $k++;
                    $current_stock_loc_field_name = $stock_loc_input_prefix."_".$k;
                    $current_qty_field_name = $qty_input_prefix."_".$k;
                }
            }
            // Simple products
            else {
                $plain_qty_field_name = $qty_input_prefix; 
                $qty_val = price2num(GETPOST($plain_qty_field_name, 'alpha'), 'MS');
                if ($qty_val > 0) {
                    $subtotal_qty_for_line = $qty_val;
                }
            }

            if ($error) break; 
            $totalqty += $subtotal_qty_for_line; 

            if (getDolGlobalInt("MAIN_DONT_SHIP_MORE_THAN_ORDERED") && $subtotal_qty_for_line > $current_order_line->qty) {
                setEventMessages($langs->trans("ErrorTooMuchShipped", ($i + 1)." - ".$product_ref_for_error_msg), null, 'errors');
                $error++;
            }

            $array_options[$i] = $extrafields->getOptionalsFromPost($object->table_element_line, $i);
            if (isset($extrafields->attributes[$object->table_element_line]['label']) && is_array($extrafields->attributes[$object->table_element_line]['label'])) {
                foreach ($extrafields->attributes[$object->table_element_line]['label'] as $key_extra => $value_extra) {
                    unset($_POST["options_".$key_extra]);
                }
            }
            if ($error) break; 
        }

        // Add shipment lines
        if (($totalqty > 0 || getDolGlobalString('SHIPMENT_GETS_ALL_ORDER_PRODUCTS')) && !$error) {
            for ($idx_add = 0; $idx_add < $num; $idx_add++) {
                $current_order_line_for_add = $objectsrc->lines[$idx_add];
                $original_line_id_for_add = GETPOSTINT("idl".$idx_add);

                // Determine the correct product ID for this line
               $is_mo_line_for_add = false;

if (empty($current_order_line_for_add->fk_product)) {
    $desc = $current_order_line_for_add->description;
    $is_mo_line_for_add = (
        (strpos($desc, 'Costum-PC') === 0 || strpos($desc, 'OF') === 0) &&
        strpos($desc, '(Fabrication)') !== false
    );
}

$fk_product_for_add = $is_mo_line_for_add ? 483 : $current_order_line_for_add->fk_product;

                // Handle batch lines
                if (isset($batch_line[$idx_add]) && is_array($batch_line[$idx_add]) && !empty($batch_line[$idx_add]['detail'])) {
                    if ($batch_line[$idx_add]['qty'] > 0 || ($batch_line[$idx_add]['qty'] == 0 && getDolGlobalString('SHIPMENT_GETS_ALL_ORDER_PRODUCTS'))) {
                        // Use the stored product ID from batch processing
                        $fk_product_for_batch = isset($batch_line[$idx_add]['fk_product']) ? $batch_line[$idx_add]['fk_product'] : $fk_product_for_add;
                        
                        $ret = $object->addline_batch($batch_line[$idx_add], $array_options[$idx_add], $fk_product_for_batch);
                        if ($ret < 0) {
                            setEventMessages($object->error, $object->errors, 'errors');
                            $error++;
                        }
                    }
                } 
                // Handle stock lines
                elseif (isset($stockLine[$idx_add])) { 
                    $nbstockline = count($stockLine[$idx_add]);
                    for ($j = 0; $j < $nbstockline; $j++) {
                        if ($stockLine[$idx_add][$j]['qty'] > 0 || ($stockLine[$idx_add][$j]['qty'] == 0 && getDolGlobalString('SHIPMENT_GETS_ALL_ORDER_PRODUCTS'))) {
                            // Use the stored product ID from stock processing
                            $fk_product_for_stock = isset($stockLine[$idx_add][$j]['fk_product']) ? $stockLine[$idx_add][$j]['fk_product'] : $fk_product_for_add;
                            
                            $ret = $object->addline($stockLine[$idx_add][$j]['warehouse_id'], $stockLine[$idx_add][$j]['ix_l'], $stockLine[$idx_add][$j]['qty'], $array_options[$idx_add], $fk_product_for_stock);
                            if ($ret < 0) {
                                setEventMessages($object->error, $object->errors, 'errors');
                                $error++;
                            }
                        }
                    }
                } 
                // Handle simple lines
                else { 
                    $qty_val_for_add = price2num(GETPOST("qtyl".$idx_add, 'alpha'), 'MS');
                    if ($qty_val_for_add > 0 || getDolGlobalString('SHIPMENT_GETS_ALL_ORDER_PRODUCTS')) {
                        $ent_field_name = "entl".$idx_add;
                        $entrepot_id_for_add = is_numeric(GETPOSTINT($ent_field_name)) ? GETPOSTINT($ent_field_name) : GETPOSTINT('entrepot_id');
                        if ($entrepot_id_for_add < 0) $entrepot_id_for_add = '';

                        // For non-product lines (services, etc.), set warehouse to 0
                        if (!($current_order_line_for_add->fk_product > 0) && !$is_mo_line_for_add) {
                            $entrepot_id_for_add = 0;
                        }
                        
                        $ret = $object->addline($entrepot_id_for_add, $original_line_id_for_add, $qty_val_for_add, $array_options[$idx_add], $fk_product_for_add);
                        if ($ret < 0) {
                            setEventMessages($object->error, $object->errors, 'errors');
                            $error++;
                        }
                    }
                }
                if ($error) break;
            }

            if (!$error) {
                $ret = $extrafields->setOptionalsFromPost(null, $object);
                if ($ret < 0) $error++;
            }

            // FIX: Improved MO detection and override with database update
            if (!$error) {
                $mo_product_id_override_final = 483;
                $product_for_mo_shipment_final = new Product($db);

                foreach ($object->lines as $key_ship_line => $shipment_line_to_be) {
                    $original_order_line_id_final = $shipment_line_to_be->origin_line_id;
                    $corresponding_order_line_final = null;
                    foreach ($objectsrc->lines as $order_line_in_source_final) {
                        if ($order_line_in_source_final->id == $original_order_line_id_final) {
                            $corresponding_order_line_final = $order_line_in_source_final;
                            break;
                        }
                    }
                    if ($corresponding_order_line_final) {
                        $is_mo_line_final = false;
                        if (empty($corresponding_order_line_final->fk_product)) {
                          $is_mo_line_final = (
            (strpos($desc, 'Costum-PC') === 0 || strpos($desc, 'OF') === 0) &&
            strpos($desc, '(Fabrication)') !== false
        );
                        }
                        if ($is_mo_line_final) {
                            if ($product_for_mo_shipment_final->fetch($mo_product_id_override_final) > 0) {
                                // Update in-memory object
                                $object->lines[$key_ship_line]->fk_product = $mo_product_id_override_final;
                                $object->lines[$key_ship_line]->fk_product_type = $product_for_mo_shipment_final->type;
                                $object->lines[$key_ship_line]->ref = $product_for_mo_shipment_final->ref;
                                $object->lines[$key_ship_line]->product_label = $product_for_mo_shipment_final->label;
                                $object->lines[$key_ship_line]->description = $product_for_mo_shipment_final->label;

                                if (getDolGlobalString('MAIN_PRODUCT_USE_UNITS') && !empty($product_for_mo_shipment_final->fk_unit)) {
                                    $object->lines[$key_ship_line]->fk_unit = $product_for_mo_shipment_final->fk_unit;
                                }
                                $object->lines[$key_ship_line]->weight = $product_for_mo_shipment_final->weight;
                                $object->lines[$key_ship_line]->weight_units = $product_for_mo_shipment_final->weight_units;
                                $object->lines[$key_ship_line]->volume = $product_for_mo_shipment_final->volume;
                                $object->lines[$key_ship_line]->volume_units = $product_for_mo_shipment_final->volume_units;
                                $object->lines[$key_ship_line]->product_tobatch = $product_for_mo_shipment_final->status_batch;
                                $object->lines[$key_ship_line]->length = $product_for_mo_shipment_final->length;
                                $object->lines[$key_ship_line]->length_units = $product_for_mo_shipment_final->length_units;
                                $object->lines[$key_ship_line]->width = $product_for_mo_shipment_final->width;
                                $object->lines[$key_ship_line]->width_units = $product_for_mo_shipment_final->width_units;
                                $object->lines[$key_ship_line]->height = $product_for_mo_shipment_final->height;
                                $object->lines[$key_ship_line]->height_units = $product_for_mo_shipment_final->height_units;
                                $object->lines[$key_ship_line]->surface = $product_for_mo_shipment_final->surface;
                                $object->lines[$key_ship_line]->surface_units = $product_for_mo_shipment_final->surface_units;

                                // Update the line in the database
                                $result = $object->lines[$key_ship_line]->update($user);
                                if ($result < 0) {
                                    $error++;
                                    setEventMessages($object->lines[$key_ship_line]->error, $object->lines[$key_ship_line]->errors, 'errors');
                                }
                            } else {
                                setEventMessages("Error: Product with rowid ".$mo_product_id_override_final." not found for final MO shipment line update.", null, 'errors');
                                $error++; break;
                            }
                        }
                    }
                }
            }

            if (!$error) {
                $ret = $object->create($user);
                if ($ret <= 0) {
                    setEventMessages($object->error, $object->errors, 'errors');
                    $error++;
                }
            }
        } elseif (!$error) {
            $ret = $extrafields->setOptionalsFromPost(null, $object);

            if (empty($conf->global->MAIN_DISABLE_DEBUG_BAR) || !empty($conf->global->MAIN_LOG_DEBUGGING)) {
                dol_syslog("Expedition card.php: 'Field Required' error triggered. totalqty=" . $totalqty . ". SHIPMENT_GETS_ALL_ORDER_PRODUCTS=" . (getDolGlobalString('SHIPMENT_GETS_ALL_ORDER_PRODUCTS') ? '1' : '0') . ". POST data: " . print_r($_POST, true), LOG_DEBUG);
            }
            $labelfieldmissing = $langs->transnoentitiesnoconv("QtyToShip");
            if (isModEnabled('stock')) {
                $labelfieldmissing .= '/'.$langs->transnoentitiesnoconv("Warehouse");
                if (isModEnabled('productbatch')) { 
                     $labelfieldmissing .= '/'.$langs->transnoentitiesnoconv("Batch");
                }
            }
            setEventMessages($langs->trans("ErrorFieldRequired", $labelfieldmissing), null, 'errors');
            $error++;
        }
    }

    if (!$error) {
        $db->commit();
        header("Location: ".$_SERVER['PHP_SELF']."?id=".$object->id);
        exit;
    } else {
        $db->rollback();
        $action = 'create'; 
    }
}elseif ($action == 'create_delivery' && getDolGlobalInt('MAIN_SUBMODULE_DELIVERY') && $user->hasRight('expedition', 'delivery', 'creer')) {
		// Build a receiving receipt
		$db->begin();

		$result = $object->create_delivery($user);
		if ($result > 0) {
			$db->commit();

			header("Location: ".DOL_URL_ROOT.'/delivery/card.php?action=create_delivery&token='.newToken().'&id='.$result);
			exit;
		} else {
			$db->rollback();

			setEventMessages($object->error, $object->errors, 'errors');
		}
	} elseif ($action == 'confirm_valid' && $confirm == 'yes' && ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('expedition', 'creer'))
		|| (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('expedition', 'shipping_advance', 'validate')))
	) {
		$object->fetch_thirdparty();

		$result = $object->valid($user);

		if ($result < 0) {
			setEventMessages($object->error, $object->errors, 'errors');
		} else {
			// Define output language
			if (!getDolGlobalString('MAIN_DISABLE_PDF_AUTOUPDATE')) {
				$outputlangs = $langs;
				$newlang = '';
				if (getDolGlobalInt('MAIN_MULTILANGS') && empty($newlang) && GETPOST('lang_id', 'aZ09')) {
					$newlang = GETPOST('lang_id', 'aZ09');
				}
				if (getDolGlobalInt('MAIN_MULTILANGS') && empty($newlang)) {
					$newlang = $object->thirdparty->default_lang;
				}
				if (!empty($newlang)) {
					$outputlangs = new Translate("", $conf);
					$outputlangs->setDefaultLang($newlang);
				}
				$model = $object->model_pdf;
				$ret = $object->fetch($id); // Reload to get new records

				$result_pdf = $object->generateDocument($model, $outputlangs, $hidedetails, $hidedesc, $hideref);
				if ($result_pdf < 0) {
					// Set a flag or directly output error, but avoid dol_print_error if we intend to redirect later
					// For now, we'll let normal error display happen and skip email/redirect if PDF fails this way.
					// The key is that dol_print_error sends output, so we must not redirect if it was called.
					// We can introduce a flag if more fine-grained control is needed.
					// However, if generateDocument calls dol_print_error internally, this check here is too late.
					// A better approach is to ensure generateDocument itself doesn't call dol_print_error OR
					// check a flag that generateDocument might set.
					// For now, let's assume if $result_pdf < 0, an error message was set via setEventMessages by generateDocument
					// and we should not proceed with auto-emailing or redirecting in that specific case.
					$pdf_generation_failed_critically = true; // Assume this if we want to prevent redirect
					dol_print_error($db, $object->error, $object->errors); // This IS THE PROBLEM if it outputs before header
				}
			}

			// Automatically send email after validation
			// Condition: PDF generation must not have critically failed (by outputting with dol_print_error)
			// OR PDF auto-update is disabled (meaning we try to use existing PDF or send without)
			$can_proceed_with_email_and_redirect = true;
			if (!getDolGlobalString('MAIN_DISABLE_PDF_AUTOUPDATE') && isset($result_pdf) && $result_pdf < 0) {
				// If PDF autoupdate is ON, and PDF generation failed AND called dol_print_error (implicitly assumed for now)
				// We should not proceed if dol_print_error was called.
				// This simple check might not be enough if generateDocument has complex error reporting.
				// For now, we assume if result_pdf < 0, error messages are set, and we might have output.
				// To be safer, we'd need generateDocument to return a clear status or avoid dol_print_error.
				// Let's assume for now that if $result_pdf < 0, we don't want to auto-email or redirect.
				$can_proceed_with_email_and_redirect = false;
				dol_syslog("Auto-email: PDF generation failed (result_pdf < 0), skipping auto-email and redirect.", LOG_WARNING);
			}

			if ($can_proceed_with_email_and_redirect) {
				dol_syslog("Auto-email TRY_BLOCK: Attempting automatic email sending for shipment ID: ".$object->id, LOG_DEBUG);
				try {
					dol_syslog("Auto-email: Starting automatic email sending process for shipment ID: ".$object->id, LOG_DEBUG);

					if (!class_exists('CMailFile')) require_once DOL_DOCUMENT_ROOT.'/core/class/CMailFile.class.php';
					if (!function_exists('dol_most_recent_file')) require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

					// Ensure $outputlangs is initialized
					dol_syslog("Auto-email: Checking outputlangs. Current state: ".(is_object($outputlangs) ? get_class($outputlangs) : gettype($outputlangs)), LOG_DEBUG);
					if (empty($outputlangs) || !is_object($outputlangs)) {
						dol_syslog("Auto-email: outputlangs is empty or not an object. Initializing.", LOG_DEBUG);
						$outputlangs = $langs; 
						if (getDolGlobalInt('MAIN_MULTILANGS') && is_object($object->thirdparty) && !empty($object->thirdparty->default_lang)) {
							$newlang_auto = $object->thirdparty->default_lang;
							dol_syslog("Auto-email: Thirdparty has default_lang: ".$newlang_auto, LOG_DEBUG);
							$outputlangs_auto_temp = new Translate("", $conf);
							$outputlangs_auto_temp->setDefaultLang($newlang_auto);
							$outputlangs_auto_temp->loadLangs(array("main", "sendings", "other", "commercial"));
							$outputlangs = $outputlangs_auto_temp;
							dol_syslog("Auto-email: Switched outputlangs to thirdparty default: ".$newlang_auto, LOG_DEBUG);
						} else {
							dol_syslog("Auto-email: Using global langs object for outputlangs.", LOG_DEBUG);
						}
					} else {
						dol_syslog("Auto-email: outputlangs was already initialized.", LOG_DEBUG);
					}
					
					dol_syslog("Auto-email: Determining recipient.", LOG_DEBUG);
					$sendto_auto = '';
					if (is_object($object->thirdparty) && $object->thirdparty->id > 0) {
						dol_syslog("Auto-email: thirdparty object is valid (ID: ".$object->thirdparty->id."). Email: ".($object->thirdparty->email ?? 'empty'), LOG_DEBUG);
						if (!empty($object->thirdparty->email)) {
							$sendto_auto = $object->thirdparty->email;
						} else {
							$contacts = $object->thirdparty->liste_contact(-1, 'external', 1);
							if (is_array($contacts) && count($contacts) > 0 && !empty($contacts[0]['email'])) {
								$sendto_auto = $contacts[0]['email'];
								dol_syslog("Auto-email: Using contact email: ".$sendto_auto, LOG_DEBUG);
							} else {
								dol_syslog("Auto-email: No thirdparty email and no contact email found.", LOG_WARNING);
							}
						}
					} else {
						dol_syslog("Auto-email: \$object->thirdparty is not valid or has no ID. Shipment ID: ".$object->id, LOG_WARNING);
					}
					dol_syslog("Auto-email: Recipient determined as: '".$sendto_auto."'", LOG_DEBUG);

					if (!empty($sendto_auto)) {
						dol_syslog("Auto-email: Determining sender.", LOG_DEBUG);
						$from_auto_name = dol_string_nospecial($conf->global->MAIN_INFO_SOCIETE_NOM ?? 'Your Company', ' ', array(","));
						$from_auto_email = getDolGlobalString('MAIN_INFO_SOCIETE_MAIL');
						if (empty($from_auto_email)) {
							if (is_object($user) && !empty($user->email)) {
								$from_auto_name = dol_string_nospecial($user->getFullName($langs), ' ', array(","));
								$from_auto_email = $user->email;
								dol_syslog("Auto-email: Using user email as sender: ".$from_auto_email, LOG_DEBUG);
							} else {
								dol_syslog("Auto-email: CRITICAL - No company or user email for sender.", LOG_ERR);
								setEventMessages($langs->trans("ErrorNoSenderEmailConfigured"), null, 'errors');
								goto after_auto_email_logic;
							}
						} else {
							dol_syslog("Auto-email: Using company email as sender: ".$from_auto_email, LOG_DEBUG);
						}
						$from_auto = $from_auto_name.' <'.$from_auto_email.'>';

						dol_syslog("Auto-email: Determining subject.", LOG_DEBUG);
						$thirdparty_name_for_subject = (is_object($object->thirdparty) && $object->thirdparty->id > 0 && !empty($object->thirdparty->name)) ? $object->thirdparty->name : $langs->transnoentities("UnknownThirdparty");
						$subject_auto = $outputlangs->transnoentities("SendShippingRef", $object->ref, $thirdparty_name_for_subject);
						if (!empty($object->ref_customer)) {
							$subject_auto = $outputlangs->transnoentities("SendShippingRefWithCustRef", $object->ref, $object->ref_customer, $thirdparty_name_for_subject);
						}
						dol_syslog("Auto-email: Subject: ".$subject_auto, LOG_DEBUG);

						dol_syslog("Auto-email: Preparing message body.", LOG_DEBUG);
						$substitutionarray_auto = getCommonSubstitutionArray($outputlangs, 0, null, $object);
						$substitutionarray_auto['__USER_SIGNATURE__'] = (is_object($user) && !empty($user->signature)) ? $user->signature : '';
						complete_substitutions_array($substitutionarray_auto, $outputlangs, $object, array('mode' => 'formemail'));
						
						$default_message_body_key = "EmailBodyShippingValidated";
						$message_auto_raw = $default_message_body_key; // Initialize with the key itself

						// Defensive checks for $outputlangs
						if (!is_object($outputlangs) || !method_exists($outputlangs, 'transnoentities') || !method_exists($outputlangs, 'loadLangs')) {
							dol_syslog("Auto-email: \$outputlangs is not a valid Translate object. Falling back to global \$langs.", LOG_ERR);
							$outputlangs = $langs; // Fallback to global $langs
						}

						// Defensive checks for $langs (should always be valid, but good practice)
						if (!is_object($langs) || !method_exists($langs, 'transnoentities') || !method_exists($langs, 'loadLangs')) {
							dol_syslog("Auto-email: Global \$langs object is not a valid Translate object. This is critical.", LOG_ERR);
							$message_auto_raw = "Dear __THIRDPARTY_NAME__,\n\nPlease find attached your shipment note __REF__.\n\nBest regards,\n__USER_SIGNATURE__";
							dol_syslog("Auto-email: Using hardcoded message due to invalid lang objects.", LOG_WARNING);
						} else {
							// Directly load 'other' for $outputlangs, method should be idempotent
							$outputlangs->loadLangs(array('other'));
							dol_syslog("Auto-email: Called loadLangs('other') for \$outputlangs.", LOG_DEBUG);
							
							$message_auto_raw = $outputlangs->transnoentities($default_message_body_key);

							if ($message_auto_raw == $default_message_body_key) { // Key not found in $outputlangs
								// Directly load 'other' for global $langs if $outputlangs is different
								if ($outputlangs !== $langs) {
									$langs->loadLangs(array('other'));
									dol_syslog("Auto-email: Called loadLangs('other') for global \$langs (fallback).", LOG_DEBUG);
								}
								$message_auto_raw = $langs->transnoentities($default_message_body_key);
							}
						}

						if ($message_auto_raw == $default_message_body_key) { // Still not found, use hardcoded fallback
							dol_syslog("Auto-email: Lang key '".$default_message_body_key."' not found. Using hardcoded fallback.", LOG_WARNING);
							$message_auto_raw = "Dear __THIRDPARTY_NAME__,\n\nPlease find attached your shipment note __REF__.\n\nBest regards,\n__USER_SIGNATURE__";
						}
						$message_auto = make_substitutions($message_auto_raw, $substitutionarray_auto);
						if (method_exists($object, 'makeSubstitution')) {
							$message_auto = $object->makeSubstitution($message_auto);
						}
						$message_auto = nl2br($message_auto);
						dol_syslog("Auto-email: Message body substitutions complete.", LOG_DEBUG);

						dol_syslog("Auto-email: Determining attachments.", LOG_DEBUG);
						$filepath_auto = array(); $filename_auto = array(); $mimetype_auto = array();
						$objectref_sanitized = dol_sanitizeFileName($object->ref ?? 'undefined_ref');
						$diroutput_shipment = ($conf->expedition->dir_output ?? '').'/sending/'.$objectref_sanitized;
						
						$file_to_attach_info = array();
						if (!empty($object->last_main_doc) && is_readable(DOL_DATA_ROOT.'/'.$object->last_main_doc) && is_file(DOL_DATA_ROOT.'/'.$object->last_main_doc)) {
							$file_to_attach_info['fullname'] = DOL_DATA_ROOT.'/'.$object->last_main_doc;
							$file_to_attach_info['name'] = basename($object->last_main_doc);
							dol_syslog("Auto-email: Attachment from last_main_doc: ".$file_to_attach_info['fullname'], LOG_DEBUG);
						} else {
							dol_syslog("Auto-email: last_main_doc not valid. Trying dol_most_recent_file in ".$diroutput_shipment, LOG_DEBUG);
							$file_to_attach_info = dol_most_recent_file($diroutput_shipment, preg_quote($objectref_sanitized, '/').'[^\-]+');
							if (!empty($file_to_attach_info['fullname'])) {
								dol_syslog("Auto-email: Attachment from dol_most_recent_file: ".$file_to_attach_info['fullname'], LOG_DEBUG);
							} else {
								dol_syslog("Auto-email: No attachment found by dol_most_recent_file.", LOG_WARNING);
							}
						}

						if (!empty($file_to_attach_info['fullname']) && is_readable($file_to_attach_info['fullname'])) {
							$filepath_auto[] = $file_to_attach_info['fullname'];
							$filename_auto[] = $file_to_attach_info['name'];
							$mimetype_auto[] = dol_mimetype($file_to_attach_info['fullname']);
							dol_syslog("Auto-email: Attachment added: ".$file_to_attach_info['name'], LOG_DEBUG);
						} else {
							dol_syslog("Auto-email: Failed to find/read attachment. Path: ".($file_to_attach_info['fullname'] ?? 'N/A'), LOG_WARNING);
							setEventMessages($langs->trans("ErrorFailedToFindAttachmentForAutoEmail", $object->ref ?? 'N/A'), null, 'warnings');
						}

						$sendtocc_auto = '';
						$sendtobcc_auto = getDolGlobalString('MAIN_MAIL_AUTOCOPY_SHIPMENT_TO');
						$deliveryreceipt_auto = getDolGlobalInt('MAIN_MAIL_SEND_DELIVERY_RECEIPT');

						dol_syslog("Auto-email: Creating CMailFile instance.", LOG_DEBUG);
						$mailfile = new CMailFile($subject_auto, $sendto_auto, $from_auto, $message_auto, $filepath_auto, $mimetype_auto, $filename_auto, $sendtocc_auto, $sendtobcc_auto, $deliveryreceipt_auto);

						dol_syslog("Auto-email: Calling sendfile(). To: ".$sendto_auto.", From: ".$from_auto.", Subject: ".$subject_auto, LOG_DEBUG);
						if ($mailfile->sendfile()) {
							dol_syslog("Auto-email: Successfully sent for shipment ID: ".$object->id, LOG_INFO);
							setEventMessages($langs->trans("MailSuccessfulySent", CMailFile::getValidAddress($from_auto, 2), CMailFile::getValidAddress($sendto_auto, 2)), null, 'mesgs');
							
							$triggersendname_auto = 'SHIPPING_SENTBYMAIL_AUTO';
							$object->sendtoid = array(); 
							if (is_object($object->thirdparty) && $object->thirdparty->id > 0) {
                            // Get an array of contact arrays, then extract the ID of the first main one
                            $contacts_for_id = $object->thirdparty->liste_contact(-1, 'external', 1, null, 0, 'MAIN'); // Fetch 1 main external contact
                            if (!empty($contacts_for_id) && is_array($contacts_for_id) && isset($contacts_for_id[0]['id'])) {
                                $object->sendtoid = array($contacts_for_id[0]['id']); // $object->sendtoid expects an array of IDs
                                dol_syslog("Auto-email: Set sendtoid for trigger to contact ID: ".$contacts_for_id[0]['id'], LOG_DEBUG);
                            } else {
                                dol_syslog("Auto-email: No main external contact ID found for thirdparty ID: ".$object->thirdparty->id." to set for sendtoid trigger.", LOG_DEBUG);
                            }
							}

							$object->actiontypecode = 'AC_SHIPMENT_SENT_AUTO';
							$object->actionmsg = substr($message_auto, 0, 2000); // Truncate if too long for DB
							$object->actionmsg2 = $langs->transnoentities('MailSentByTo', CMailFile::getValidAddress($from_auto, 4, 0, 1), CMailFile::getValidAddress($sendto_auto, 4, 0, 1));
							if (getDolGlobalString('MAIN_MAIL_REPLACE_EVENT_TITLE_BY_EMAIL_SUBJECT')) {
								$object->actionmsg2 = $subject_auto;
							}
							$object->trackid = 'shi'.($object->id ?? 'unknownid').'_auto_'.time();
							$object->email_from = $from_auto;
							$object->email_to = $sendto_auto;
							$object->email_subject = $subject_auto;
							$object->email_msgid = $mailfile->msgid;
							
							if (is_object($user)) {
								dol_syslog("Auto-email: Calling trigger ".$triggersendname_auto." for user ID: ".$user->id, LOG_DEBUG);
								$object->call_trigger($triggersendname_auto, $user);
							} else {
								dol_syslog("Auto-email: User object not valid, cannot call trigger. Shipment ID: ".$object->id, LOG_ERR);
							}
						} else {
							$errorMessage = $langs->transnoentities('ErrorFailedToSendMail', dol_escape_htmltag($from_auto), dol_escape_htmltag($sendto_auto));
							if (!empty($mailfile->error)) $errorMessage .= '<br>'.$mailfile->error;
							if (!empty($mailfile->errors) && is_array($mailfile->errors)) $errorMessage .= '<br>'.implore('<br>', $mailfile->errors);
							dol_syslog("Auto-email: Failed to send. Error: ".$errorMessage.". Shipment ID: ".$object->id, LOG_ERR);
							setEventMessages(null, array($errorMessage), 'errors');
						}
					} else {
						$thirdparty_name_for_error = (is_object($object->thirdparty) && !empty($object->thirdparty->name)) ? $object->thirdparty->name : $langs->transnoentities("UnknownThirdparty");
						dol_syslog("Auto-email: No recipient email. Thirdparty: ".$thirdparty_name_for_error.". Shipment ID: ".$object->id, LOG_WARNING);
						setEventMessages($langs->trans("ErrorNoRecipientEmailForAutoSend", $thirdparty_name_for_error), null, 'warnings');
					}
				} catch (Throwable $t) {
					$errorMessage = "ErrorDuringAutomaticEmail: ".$t->getMessage()." in ".$t->getFile()." on line ".$t->getLine();
					$stackTrace = $t->getTraceAsString();
					dol_syslog("Auto-email CATCH_BLOCK: Throwable caught during automatic email sending for shipment ID: ".$object->id.". Error: ".$errorMessage, LOG_ERR);
					dol_syslog("Auto-email CATCH_BLOCK: Stack Trace:\n".$stackTrace, LOG_ERR);
					setEventMessages($langs->trans("ErrorDuringAutomaticEmail").": ".$t->getMessage(), null, 'errors'); // User-facing message remains concise
				}
				dol_syslog("Auto-email TRY_BLOCK: Finished automatic email sending attempt for shipment ID: ".$object->id, LOG_DEBUG);
			}
			after_auto_email_logic:; 

			// Redirect to the card to show results and prevent re-execution on reload
			$redirect_url = $_SERVER["PHP_SELF"]."?id=".$object->id;
			// It might be useful to add a confirmation message key if needed, e.g., by appending '&confmsg=shipmentvalidatedemailed'
			// setEventMessages will handle specific success/error messages for the email part.
			// The main "validated" status is usually clear from the card view itself.
			header("Location: ".$redirect_url);
			exit;
		}
	} elseif ($action == 'confirm_cancel' && $confirm == 'yes' && $user->hasRight('expedition', 'creer')) {
		$also_update_stock = (GETPOST('alsoUpdateStock', 'alpha') ? 1 : 0);
		$result = $object->cancel(0, $also_update_stock);
		if ($result > 0) {
			$result = $object->setStatut(-1);
		} else {
			setEventMessages($object->error, $object->errors, 'errors');
		}
	} elseif ($action == 'confirm_delete' && $confirm == 'yes' && $user->hasRight('expedition', 'supprimer')) {
		$also_update_stock = (GETPOST('alsoUpdateStock', 'alpha') ? 1 : 0);
		$result = $object->delete($user, 0, $also_update_stock);
		if ($result > 0) {
			header("Location: ".DOL_URL_ROOT.'/expedition/index.php');
			exit;
		} else {
			setEventMessages($object->error, $object->errors, 'errors');
		}
		// TODO add alternative status
		//} elseif ($action == 'reopen' && ($user->hasRight('expedition', 'creer') || $user->hasRight('expedition', 'shipping_advance', 'validate')))
		//{
		//	$result = $object->setStatut(0);
		//	if ($result < 0)
		//	{
		//		setEventMessages($object->error, $object->errors, 'errors');
		//	}
		//}
	} elseif ($action == 'setdate_livraison' && $user->hasRight('expedition', 'creer')) {
		$datedelivery = dol_mktime(GETPOSTINT('liv_hour'), GETPOSTINT('liv_min'), 0, GETPOSTINT('liv_month'), GETPOSTINT('liv_day'), GETPOSTINT('liv_year'));

		$object->fetch($id);
		$result = $object->setDeliveryDate($user, $datedelivery);
		if ($result < 0) {
			setEventMessages($object->error, $object->errors, 'errors');
		}
	} elseif ($action == 'setdate_shipping' && $user->hasRight('expedition', 'creer')) {
		$dateshipping = dol_mktime(GETPOSTINT('ship_hour'), GETPOSTINT('ship_min'), 0, GETPOSTINT('ship_month'), GETPOSTINT('ship_day'), GETPOSTINT('ship_year'));

		$object->fetch($id);
		$result = $object->setShippingDate($user, $dateshipping);
		if ($result < 0) {
			setEventMessages($object->error, $object->errors, 'errors');
		}
	} elseif (in_array($action, array('settracking_number', 'settracking_url', 'settrueWeight', 'settrueWidth', 'settrueHeight', 'settrueDepth', 'setshipping_method_id')) && $user->hasRight('expedition', 'creer')) {
		// Action update
		$error = 0;

		if ($action == 'settracking_number') {
			$object->tracking_number = trim(GETPOST('tracking_number', 'alpha'));
		}
		if ($action == 'settracking_url') {
			$object->tracking_url = trim(GETPOST('tracking_url', 'restricthtml'));
		}
		if ($action == 'settrueWeight') {
			$object->trueWeight = GETPOSTINT('trueWeight');
			$object->weight_units = GETPOSTINT('weight_units');
		}
		if ($action == 'settrueWidth') {
			$object->trueWidth = GETPOSTINT('trueWidth');
		}
		if ($action == 'settrueHeight') {
			$object->trueHeight = GETPOSTINT('trueHeight');
			$object->size_units = GETPOSTINT('size_units');
		}
		if ($action == 'settrueDepth') {
			$object->trueDepth = GETPOSTINT('trueDepth');
		}
		if ($action == 'setshipping_method_id') {
			$object->shipping_method_id = GETPOSTINT('shipping_method_id');
		}

		if (!$error) {
			if ($object->update($user) >= 0) {
				header("Location: card.php?id=".$object->id);
				exit;
			}
			setEventMessages($object->error, $object->errors, 'errors');
		}

		$action = "";
	} elseif ($action == 'classifybilled' && $permissiontoadd) {
		$object->fetch($id);
		$result = $object->setBilled();
		if ($result >= 0) {
			header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
			exit();
		}
		setEventMessages($object->error, $object->errors, 'errors');
	} elseif ($action == 'classifyclosed' && $permissiontoadd) {
		$object->fetch($id);
		$result = $object->setClosed();
		if ($result >= 0) {
			header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
			exit();
		}
		setEventMessages($object->error, $object->errors, 'errors');
	} elseif ($action == 'deleteline' && !empty($line_id) && $permissiontoadd) {
		// delete a line
		$object->fetch($id);
		$lines = $object->lines;
		$line = new ExpeditionLigne($db);
		$line->fk_expedition = $object->id;

		$num_prod = count($lines);
		for ($i = 0; $i < $num_prod; $i++) {
			if ($lines[$i]->id == $line_id) {
				if (count($lines[$i]->details_entrepot) > 1) {
					// delete multi warehouse lines
					foreach ($lines[$i]->details_entrepot as $details_entrepot) {
						$line->id = $details_entrepot->line_id;
						if (!$error && $line->delete($user) < 0) {
							$error++;
						}
					}
				} else {
					// delete single warehouse line
					$line->id = $line_id;
					if (!$error && $line->delete($user) < 0) {
						$error++;
					}
				}
			}
			unset($_POST["lineid"]);
		}

		if (!$error) {
			header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
			exit();
		} else {
			setEventMessages($line->error, $line->errors, 'errors');
		}
	} elseif ($action == 'updateline' && $permissiontoadd && GETPOST('save')) {
		// Update a line
		$lines = $object->lines;
		$num_prod = count($lines);
		for ($i = 0; $i < $num_prod; $i++) {
			if ($lines[$i]->id == $line_id) { // we have found line to update
				$update_done = false;
				$line = new ExpeditionLigne($db);
				$line->fk_expedition = $object->id;
				$line->array_options = $extrafields->getOptionalsFromPost($object->table_element_line);
				if (is_array($extrafields->attributes[$object->table_element_line]['label'])) {
					foreach ($extrafields->attributes[$object->table_element_line]['label'] as $key => $value) {
						unset($_POST["options_".$key]);
					}
				}
				$line->fk_product = $lines[$i]->fk_product;

				if (is_array($lines[$i]->detail_batch) && count($lines[$i]->detail_batch) > 0) {
					// line with lot
					foreach ($lines[$i]->detail_batch as $detail_batch) {
						$lotStock = new Productbatch($db);
						$qty = "qtyl".$detail_batch->fk_expeditiondet.'_'.$detail_batch->id;
						$batch_text = GETPOST("batch_text_l".$detail_batch->fk_expeditiondet.'_'.$detail_batch->id, 'alpha');
						$warehouse_id = GETPOSTINT("entl".$detail_batch->fk_expeditiondet.'_'.$detail_batch->id);
						$batch_qty = GETPOSTFLOAT($qty);
						$batch_id = 0;

						if ($batch_qty > 0 && !empty($batch_text)) {
							$sql_find = "SELECT t.rowid FROM ".MAIN_DB_PREFIX."product_batch as t INNER JOIN ".MAIN_DB_PREFIX."product_stock as ps ON t.fk_product_stock = ps.rowid WHERE t.batch = '".$db->escape($batch_text)."' AND ps.fk_product = ".((int) $lines[$i]->fk_product);
							if ($warehouse_id > 0) $sql_find .= " AND ps.fk_entrepot = ".$warehouse_id;
							$res_find = $db->query($sql_find);
							if ($res_find && $db->num_rows($res_find) > 0) {
								$obj_find = $db->fetch_object($res_find);
								$batch_id = $obj_find->rowid;
							} else {
								setEventMessages("The batch/serial entered '".dol_escape_htmltag($batch_text)."' does not exist for this product/warehouse.", null, 'errors');
								$error++; continue;
							}
						}

						if (!empty($batch_id)) {
							if ($lotStock->fetch($batch_id) > 0 && $line->fetch($detail_batch->fk_expeditiondet) > 0) {
								if ($lines[$i]->entrepot_id != 0) $line->entrepot_id = $lotStock->warehouseid;
								if (empty($line->detail_batch)) $line->detail_batch = new stdClass();
								$line->detail_batch->fk_origin_stock = $batch_id;
								$line->detail_batch->batch = $lotStock->batch;
								$line->detail_batch->id = $detail_batch->id;
								$line->detail_batch->entrepot_id = $lotStock->warehouseid;
								$line->detail_batch->qty = $batch_qty;
								if ($line->update($user) < 0) { setEventMessages($line->error, $line->errors, 'errors'); $error++; } else { $update_done = true; }
							} else { setEventMessages($lotStock->error, $lotStock->errors, 'errors'); $error++; }
						}
					}

					// add new batch
					$lotStock = new Productbatch($db);
					$batch_text = GETPOST("batch_text_l".$line_id."_0", 'alpha');
					$qty = "qtyl".$line_id."_0";
					$warehouse_id_new = GETPOSTINT("entl".$line_id."_0");
					$batch_qty = GETPOSTFLOAT($qty);
					$batch_id = 0;

					if ($batch_qty > 0 && !empty($batch_text)) {
						$sql_find_new = "SELECT t.rowid FROM ".MAIN_DB_PREFIX."product_batch as t INNER JOIN ".MAIN_DB_PREFIX."product_stock as ps ON t.fk_product_stock = ps.rowid WHERE t.batch = '".$db->escape($batch_text)."' AND ps.fk_product = ".((int) $lines[$i]->fk_product);
						if ($warehouse_id_new > 0) $sql_find_new .= " AND ps.fk_entrepot = ".$warehouse_id_new;
						$res_find_new = $db->query($sql_find_new);
						if ($res_find_new && $db->num_rows($res_find_new) > 0) {
							$obj_find_new = $db->fetch_object($res_find_new);
							$batch_id = $obj_find_new->rowid;
						} else {
							setEventMessages("The new batch/serial entered '".dol_escape_htmltag($batch_text)."' does not exist.", null, 'errors');
							$error++;
						}

						if ($batch_id > 0 && $lotStock->fetch($batch_id) > 0) {
							$lineIdToAddLot = 0;
							if ($lines[$i]->entrepot_id > 0) {
								if ($lines[$i]->entrepot_id == $lotStock->warehouseid) $lineIdToAddLot = $line_id;
							} elseif (count($lines[$i]->details_entrepot) > 1) {
								foreach ($lines[$i]->details_entrepot as $detail_entrepot) {
									if ($detail_entrepot->entrepot_id == $lotStock->warehouseid) $lineIdToAddLot = $detail_entrepot->line_id;
								}
							}
							if ($lineIdToAddLot) {
								if ($line->fetch($lineIdToAddLot) > 0) {
									$line->detail_batch->fk_origin_stock = $batch_id;
									$line->detail_batch->batch = $lotStock->batch;
									$line->detail_batch->entrepot_id = $lotStock->warehouseid;
									$line->detail_batch->qty = $batch_qty;
									if ($line->update($user) < 0) { setEventMessages($line->error, $line->errors, 'errors'); $error++; } else { $update_done = true; }
								} else { setEventMessages($line->error, $line->errors, 'errors'); $error++; }
							} else {
								$line->origin_line_id = $lines[$i]->origin_line_id;
								$line->entrepot_id = $lotStock->warehouseid;
								$line->detail_batch[0] = new ExpeditionLineBatch($db);
								$line->detail_batch[0]->fk_origin_stock = $batch_id;
								$line->detail_batch[0]->batch = $lotStock->batch;
								$line->detail_batch[0]->entrepot_id = $lotStock->warehouseid;
								$line->detail_batch[0]->qty = $batch_qty;
								if ($object->create_line_batch($line, $line->array_options) < 0) { setEventMessages($object->error, $object->errors, 'errors'); $error++; } else { $update_done = true; }
							}
						} elseif (!$error) { setEventMessages($lotStock->error, $lotStock->errors, 'errors'); $error++; }
					}
				} else {
					// Standard product line update
					if ($lines[$i]->fk_product > 0) {
						if ($lines[$i]->entrepot_id == 0 || $lines[$i]->entrepot_id > 0) {
							$qty = "qtyl".$line_id;
							$line->id = $line_id;
							$line->entrepot_id = GETPOSTINT("entl".$line_id);
							$line->qty = GETPOSTFLOAT($qty);
							if ($line->update($user) < 0) { setEventMessages($line->error, $line->errors, 'errors'); $error++; }
						} elseif (count($lines[$i]->details_entrepot) > 1) {
							foreach ($lines[$i]->details_entrepot as $detail_entrepot) {
								if (!$error) {
									$warehouse = GETPOSTINT("entl".$detail_entrepot->line_id);
									if (!empty($warehouse)) {
										$line->id = $detail_entrepot->line_id;
										$line->entrepot_id = $warehouse;
										$line->qty = GETPOSTFLOAT("qtyl".$detail_entrepot->line_id);
										if ($line->update($user) < 0) { setEventMessages($line->error, $line->errors, 'errors'); $error++; } else { $update_done = true; }
									}
								}
							}
						} elseif (!isModEnabled('stock') && empty($conf->productbatch->enabled)) {
							$qty = "qtyl".$line_id;
							$line->id = $line_id;
							$line->qty = GETPOSTFLOAT($qty);
							$line->entrepot_id = 0;
							if ($line->update($user) < 0) { setEventMessages($line->error, $line->errors, 'errors'); $error++; } else { $update_done = true; }
						}
					} else {
						// Free text line
						$qty = "qtyl".$line_id;
						$line->id = $line_id;
						$line->qty = GETPOSTFLOAT($qty);
						$line->entrepot_id = 0;
						if ($line->update($user) < 0) { setEventMessages($line->error, $line->errors, 'errors'); $error++; } else { $update_done = true; }
					}
				}

				if (empty($update_done)) {
					$line->id = $lines[$i]->id;
					$line->insertExtraFields();
				}
			}
		}

		unset($_POST["lineid"]);

		if (!$error) {
			if (!getDolGlobalString('MAIN_DISABLE_PDF_AUTOUPDATE')) {
				// Define output language
				$outputlangs = $langs;
				$newlang = '';
				if (getDolGlobalInt('MAIN_MULTILANGS') && empty($newlang) && GETPOST('lang_id', 'aZ09')) {
					$newlang = GETPOST('lang_id', 'aZ09');
				}
				if (getDolGlobalInt('MAIN_MULTILANGS') && empty($newlang)) {
					$newlang = $object->thirdparty->default_lang;
				}
				if (!empty($newlang)) {
					$outputlangs = new Translate("", $conf);
					$outputlangs->setDefaultLang($newlang);
				}

				$ret = $object->fetch($object->id); // Reload to get new records
				$object->generateDocument($object->model_pdf, $outputlangs, $hidedetails, $hidedesc, $hideref);
			}
		} else {
			header('Location: '.$_SERVER['PHP_SELF'].'?id='.$object->id); // To redisplay the form being edited
			exit();
		}
	} elseif ($action == 'updateline' && $permissiontoadd && GETPOST('cancel', 'alpha') == $langs->trans("Cancel")) {
		header('Location: '.$_SERVER['PHP_SELF'].'?id='.$object->id); // To redisplay the form being edited
		exit();
	}

	include DOL_DOCUMENT_ROOT.'/core/actions_printing.inc.php';

	// Actions to send emails
	if (empty($id)) {
		$id = $facid;
	}
	$triggersendname = 'SHIPPING_SENTBYMAIL';
	$paramname = 'id';
	$autocopy = 'MAIN_MAIL_AUTOCOPY_SHIPMENT_TO';
	$mode = 'emailfromshipment';
	$trackid = 'shi'.$object->id;
	include DOL_DOCUMENT_ROOT.'/core/actions_sendmails.inc.php';
}


/*
 * View
 */

$title = $object->ref.' - '.$langs->trans("Shipment");
if ($action == 'create2') {
	$title = $langs->trans("CreateShipment");
}
$help_url = 'EN:Module_Shipments|FR:Module_ExpÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â©ditions|ES:M&oacute;dulo_Expediciones|DE:Modul_Lieferungen';

llxHeader('', $title, $help_url, '', 0, 0, '', '', '', 'mod-expedition page-card');

if (empty($action)) {
	$action = 'view';
}

$form = new Form($db);
$formfile = new FormFile($db);
$formproduct = new FormProduct($db);
if (isModEnabled('project')) {
	$formproject = new FormProjets($db);
} else {
	$formproject = null;
}

$product_static = new Product($db);
$shipment_static = new Expedition($db);
$warehousestatic = new Entrepot($db);

if ($action == 'create2') {
	print load_fiche_titre($langs->trans("CreateShipment"), '', 'dolly');

	print '<br>'.$langs->trans("ShipmentCreationIsDoneFromOrder");
	$action = '';
	$id = '';
	$ref = '';
}

// Mode creation.
if ($action == 'create') {
	$expe = new Expedition($db);

	print load_fiche_titre($langs->trans("CreateShipment"), '', 'dolly');

	if (!$origin) {
		setEventMessages($langs->trans("ErrorBadParameters"), null, 'errors');
	}

	if ($origin) {
		$classname = ucfirst($origin);

		$object = new $classname($db); // This $object is the Sales Order (source object)
		'@phan-var-force Commande|Facture $object';
		if ($object->fetch($origin_id)) {	// This include the fetch_lines
			$soc = new Societe($db);
			$soc->fetch($object->socid);

			$author = new User($db);
			$author->fetch($object->user_author_id);

			if (isModEnabled('stock')) {
				$entrepot = new Entrepot($db);
			}

			print '<form action="'.$_SERVER["PHP_SELF"].'" method="post">';
			print '<input type="hidden" name="token" value="'.newToken().'">';
			print '<input type="hidden" name="action" value="add">';
			print '<input type="hidden" name="origin" value="'.$origin.'">';
			print '<input type="hidden" name="origin_id" value="'.$object->id.'">';
			if (GETPOSTINT('entrepot_id')) {
				print '<input type="hidden" name="entrepot_id" value="'.GETPOSTINT('entrepot_id').'">';
			}

			print dol_get_fiche_head([]);

			print '<table class="border centpercent">';

			// Ref
			print '<tr><td class="titlefieldcreate fieldrequired">';
			if ($origin == 'commande' && isModEnabled('order')) {
				print $langs->trans("RefOrder");
			}
			if ($origin == 'propal' && isModEnabled("propal")) {
				print $langs->trans("RefProposal");
			}
			print '</td><td colspan="3">';
			print $object->getNomUrl(1);
			print '</td>';
			print "</tr>\n";

			// Ref client
			print '<tr><td>';
			if ($origin == 'commande') {
				print $langs->trans('RefCustomerOrder');
			} elseif ($origin == 'propal') {
				print $langs->trans('RefCustomerOrder');
			} else {
				print $langs->trans('RefCustomer');
			}
			print '</td><td colspan="3">';
			print '<input type="text" name="ref_customer" value="'.$object->ref_client.'" />';
			print '</td>';
			print '</tr>';

			// Tiers
			print '<tr><td class="titlefieldcreate fieldrequired">'.$langs->trans('Company').'</td>';
			print '<td colspan="3">'.$soc->getNomUrl(1).'</td>';
			print '</tr>';

			// Project
			if (isModEnabled('project') && is_object($formproject)) {
				$projectid = GETPOSTINT('projectid') ? GETPOSTINT('projectid') : 0;
				if (empty($projectid) && !empty($object->fk_project)) {
					$projectid = $object->fk_project;
				}
				if ($origin == 'project') {
					$projectid = ($originid ? $originid : 0);
				}

				$langs->load("projects");
				print '<tr>';
				print '<td>'.$langs->trans("Project").'</td><td colspan="2">';
				print img_picto('', 'project', 'class="pictofixedwidth"');
				print $formproject->select_projects($soc->id, $projectid, 'projectid', 0, 0, 1, 0, 0, 0, 0, '', 1, 0, 'widthcentpercentminusxx');
				print ' <a class="paddingleft" href="'.DOL_URL_ROOT.'/projet/card.php?socid='.$soc->id.'&action=create&status=1&backtopage='.urlencode($_SERVER["PHP_SELF"].'?action=create&socid='.$soc->id).'"><span class="fa fa-plus-circle valignmiddle"></span></a>';
				print '</td>';
				print '</tr>';
			}

			// Date delivery planned
			print '<tr><td>'.$langs->trans("DateDeliveryPlanned").'</td>';
			print '<td colspan="3">';
			print img_picto('', 'action', 'class="pictofixedwidth"');
			$date_delivery = ($date_delivery ? $date_delivery : $object->delivery_date); // $date_delivery comes from GETPOST
			print $form->selectDate($date_delivery ? $date_delivery : -1, 'date_delivery', 1, 1, 1);
			print "</td>\n";
			print '</tr>';

			// Date sending
			print '<tr><td>'.$langs->trans("DateShipping").'</td>';
			print '<td colspan="3">';
			print img_picto('', 'action', 'class="pictofixedwidth"');
			$date_shipping = ($date_shipping ? $date_shipping : $object->date_shipping); // $date_shipping comes from GETPOST
			print $form->selectDate($date_shipping ? $date_shipping : -1, 'date_shipping', 1, 1, 1);
			print "</td>\n";
			print '</tr>';

			// Note Public
			print '<tr><td>'.$langs->trans("NotePublic").'</td>';
			print '<td colspan="3">';
			$doleditor = new DolEditor('note_public', $object->note_public, '', 60, 'dolibarr_notes', 'In', false, false, !getDolGlobalString('FCKEDITOR_ENABLE_NOTE_PUBLIC') ? 0 : 1, ROWS_3, '90%');
			print $doleditor->Create(1);
			print "</td></tr>";

			// Note Private
			if ($object->note_private && !$user->socid) {
				print '<tr><td>'.$langs->trans("NotePrivate").'</td>';
				print '<td colspan="3">';
				$doleditor = new DolEditor('note_private', $object->note_private, '', 60, 'dolibarr_notes', 'In', false, false, !getDolGlobalString('FCKEDITOR_ENABLE_NOTE_PRIVATE') ? 0 : 1, ROWS_3, '90%');
				print $doleditor->Create(1);
				print "</td></tr>";
			}

			// Weight
			print '<tr><td>';
			print $langs->trans("Weight");
			print '</td><td colspan="3">';
			print img_picto('', 'fa-balance-scale', 'class="pictofixedwidth"');
			print '<input name="weight" size="4" value="'.GETPOSTINT('weight').'"> ';
			$text = $formproduct->selectMeasuringUnits("weight_units", "weight", GETPOSTINT('weight_units'), 0, 2);
			$htmltext = $langs->trans("KeepEmptyForAutoCalculation");
			print $form->textwithpicto($text, $htmltext);
			print '</td></tr>';
			// Dim
			print '<tr><td>';
			print $langs->trans("Width").' x '.$langs->trans("Height").' x '.$langs->trans("Depth");
			print ' </td><td colspan="3">';
			print img_picto('', 'fa-ruler', 'class="pictofixedwidth"');
			print '<input name="sizeW" size="4" value="'.GETPOSTINT('sizeW').'">';
			print ' x <input name="sizeH" size="4" value="'.GETPOSTINT('sizeH').'">';
			print ' x <input name="sizeS" size="4" value="'.GETPOSTINT('sizeS').'">';
			print ' ';
			$text = $formproduct->selectMeasuringUnits("size_units", "size", GETPOSTINT('size_units'), 0, 2);
			$htmltext = $langs->trans("KeepEmptyForAutoCalculation");
			print $form->textwithpicto($text, $htmltext);
			print '</td></tr>';

			// Delivery method
			print "<tr><td>".$langs->trans("DeliveryMethod")."</td>";
			print '<td colspan="3">';
			$expe->fetch_delivery_methods();
			print img_picto('', 'dolly', 'class="pictofixedwidth"');
			print $form->selectarray("shipping_method_id", $expe->meths, GETPOSTINT('shipping_method_id'), 1, 0, 0, "", 1, 0, 0, '', 'widthcentpercentminusxx');
			if ($user->admin) {
				print info_admin($langs->trans("YouCanChangeValuesForThisListFromDictionarySetup"), 1);
			}
			print "</td></tr>\n";

			// Tracking number
			print "<tr><td>".$langs->trans("TrackingNumber")."</td>";
			print '<td colspan="3">';
			print img_picto('', 'barcode', 'class="pictofixedwidth"');
			print '<input name="tracking_number" size="20" value="'.GETPOST('tracking_number', 'alpha').'">';
			print "</td></tr>\n";

			// Other attributes
			$parameters = array('objectsrc' => isset($objectsrc) ? $objectsrc : '', 'colspan' => ' colspan="3"', 'cols' => '3', 'socid' => $socid);
			$reshook = $hookmanager->executeHooks('formObjectOptions', $parameters, $expe, $action); // Note that $action and $object may have been modified by hook
			print $hookmanager->resPrint;

			if (empty($reshook)) {
				// copy from order
				if ($object->fetch_optionals() > 0) {
					$expe->array_options = array_merge($expe->array_options, $object->array_options);
				}
				print $expe->showOptionals($extrafields, 'edit', $parameters);
			}


			// Incoterms
			if (isModEnabled('incoterm')) {
				print '<tr>';
				print '<td><label for="incoterm_id">'.$form->textwithpicto($langs->trans("IncotermLabel"), $object->label_incoterms, 1).'</label></td>';
				print '<td colspan="3" class="maxwidthonsmartphone">';
				print img_picto('', 'incoterm', 'class="pictofixedwidth"');
				print $form->select_incoterms((!empty($object->fk_incoterms) ? $object->fk_incoterms : ''), (!empty($object->location_incoterms) ? $object->location_incoterms : ''));
				print '</td></tr>';
			}

			// Document model
			include_once DOL_DOCUMENT_ROOT.'/core/modules/expedition/modules_expedition.php';
			$list = ModelePdfExpedition::liste_modeles($db);
			if (is_countable($list) && count($list) > 1) {
				print "<tr><td>".$langs->trans("DefaultModel")."</td>";
				print '<td colspan="3">';
				print img_picto('', 'pdf', 'class="pictofixedwidth"');
				print $form->selectarray('model', $list, getDolGlobalString('EXPEDITION_ADDON_PDF'), 0, 0, 0, '', 0, 0, 0, '', 'widthcentpercentminusx');
				print "</td></tr>\n";
			}

			print "</table>";

			print dol_get_fiche_end();

// --- BEGINNING OF NEW CODE BLOCK (Modify llx_commandedet for MO lines) ---
if ($origin == 'commande' && isset($object->id) && $object->id > 0 && !empty($object->lines) && is_array($object->lines)) {
    $product_id_for_mo = 483; // As specified
    // Determine product_type for product 483. Fetching it once would be efficient.
    $product_type_for_mo = null;
    if (!class_exists('Product')) { // Ensure Product class is available
        require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
    }
    $temp_product_for_type = new Product($db);
    if ($temp_product_for_type->fetch($product_id_for_mo) > 0) {
        $product_type_for_mo = $temp_product_for_type->type;
    } else {
        dol_syslog("expedition/card.php: Warning - Could not fetch Product ID " . $product_id_for_mo . " to determine its type. MO lines might not have correct product_type set on order line.", LOG_WARNING);
        // Fallback to a generic product type if product 483 cannot be fetched, though this indicates a setup issue.
        $product_type_for_mo = Product::TYPE_PRODUCT;
    }

    if (!class_exists('OrderLine')) { // Ensure OrderLine class is available
        require_once DOL_DOCUMENT_ROOT.'/commande/class/orderline.class.php';
    }

    foreach ($object->lines as $index => $orderLineDataInMemory) {
        // Identify MO line based on its *original* state (empty fk_product and description)
        // $orderLineDataInMemory is a snapshot. We fetch the actual line for update to avoid issues with partial objects.
        $is_mo_line_for_update = false;
      if (
    empty($orderLineDataInMemory->fk_product) &&
    isset($orderLineDataInMemory->description)
) {
    $desc = $orderLineDataInMemory->description;
    if (
        (strpos($desc, 'Costum-PC') === 0 || strpos($desc, 'OF') === 0) &&
        strpos($desc, '(Fabrication)') !== false
    ) {
        $is_mo_line_for_update = true;
    }
}


        // Only proceed if it's an MO line AND its fk_product in memory is not already the target MO product ID
        // (this check on $orderLineDataInMemory->fk_product helps prevent re-processing if page is reloaded weirdly,
        // though the primary guard is empty fk_product for initial identification)
        if ($is_mo_line_for_update && $orderLineDataInMemory->fk_product != $product_id_for_mo) {
            dol_syslog("expedition/card.php: Attempting to update OrderLine ID " . $orderLineDataInMemory->id . " for MO. Setting fk_product to " . $product_id_for_mo, LOG_DEBUG);

            $line_to_update = new OrderLine($db);
            $fetch_result = $line_to_update->fetch($orderLineDataInMemory->id); // Fetch by ID

            if ($fetch_result > 0) {
                // Double check if it's an MO line based on fetched DB state, if fk_product is still 0 or null
                // This ensures we only update if it hasn't been updated by another process/reload.
                if (empty($line_to_update->fk_product)) {
                    $line_to_update->fk_product = $product_id_for_mo;
                    if ($product_type_for_mo !== null) {
                        $line_to_update->product_type = $product_type_for_mo;
                    }
                    // Note: $user should be available in this context (expedition/card.php)
                    $update_result = $line_to_update->update($user);

                    if ($update_result > 0) {
                        dol_syslog("expedition/card.php: Successfully updated OrderLine ID " . $line_to_update->id . " in DB. fk_product is now " . $product_id_for_mo, LOG_DEBUG);
                        // Update the in-memory $object->lines array as well
                        $object->lines[$index]->fk_product = $product_id_for_mo;
                        if ($product_type_for_mo !== null) {
                             $object->lines[$index]->product_type = $product_type_for_mo;
                        }
                        // If Product 483's label should replace the MO description for display on this page:
                        // $object->lines[$index]->product_label = $temp_product_for_type->label; // Assumes $temp_product_for_type is Product 483
                        // $object->lines[$index]->label = $temp_product_for_type->label;
                    } else {
                        dol_syslog("expedition/card.php: Failed to update OrderLine ID " . $line_to_update->id . " in DB. Error: " . $line_to_update->error, LOG_ERR);
                        setEventMessages($langs->trans("ErrorFailedToUpdateOrderLineForMO", $line_to_update->id) . ': ' . $line_to_update->error, $line_to_update->errors, 'errors');
                    }
                } else {
                     dol_syslog("expedition/card.php: OrderLine ID " . $line_to_update->id . " already has fk_product = " . $line_to_update->fk_product . ". Skipping update.", LOG_DEBUG);
                     // Sync in-memory object if DB was already updated
                     if ($line_to_update->fk_product == $product_id_for_mo) {
                         $object->lines[$index]->fk_product = $line_to_update->fk_product;
                         $object->lines[$index]->product_type = $line_to_update->product_type;
                     }
                }
            } else {
                dol_syslog("expedition/card.php: Failed to fetch OrderLine ID " . $orderLineDataInMemory->id . " for update. Fetch result: " . $fetch_result, LOG_ERR);
                setEventMessages($langs->trans("ErrorFailedToFetchOrderLineForMOUpdate", $orderLineDataInMemory->id), null, 'errors');
            }
        }
    }
}
// --- END OF NEW CODE BLOCK ---

			// Shipment lines

			$numAsked = count($object->lines); // $object is Sales Order here

			print '<script type="text/javascript">'."\n";
			print 'jQuery(document).ready(function() {'."\n";
			print 'jQuery("#autofill").click(function() {';
			$i = 0;
			while ($i < $numAsked) {
				print 'jQuery("#qtyl'.$i.'").val(jQuery("#qtyasked'.$i.'").val() - jQuery("#qtydelivered'.$i.'").val());'."\n";
				if (isModEnabled('productbatch')) {
					// This might need adjustment if MO lines have different batch input IDs
					print 'jQuery("#qtyl'.$i.'_'.$i.'").val(jQuery("#qtyasked'.$i.'").val() - jQuery("#qtydelivered'.$i.'").val());'."\n";
				}
				$i++;
			}
			print 'return false; });'."\n";
			print 'jQuery("#autoreset").click(function() { console.log("Reset values to 0"); jQuery(".qtyl").val(0);'."\n";
			print 'return false; });'."\n";
			print '});'."\n";
			print '</script>'."\n";

			print '<br>';

			print '<div class="div-table-responsive-no-min">';
			print '<table class="noborder centpercent">';

			// Load shipments already done for same order
			$object->loadExpeditions();


			$alreadyQtyBatchSetted = $alreadyQtySetted = array();

			if ($numAsked) {
				print '<tr class="liste_titre">';
				print '<td>'.$langs->trans("Description").'</td>';
				print '<td class="center">'.$langs->trans("QtyOrdered").'</td>';
				print '<td class="center">'.$langs->trans("QtyShipped").'</td>';
				print '<td class="center">'.$langs->trans("QtyToShip");
				if (empty($conf->productbatch->enabled)) { // This check might need to be more nuanced if Product 483 has batches
					print '<br><a href="#" id="autofill" class="opacitymedium link cursor cursorpointer">'.img_picto($langs->trans("Autofill"), 'autofill', 'class="paddingrightonly"').'</a>';
					print ' / ';
				} else {
					print '<br>';
				}
				print '<span id="autoreset" class="opacitymedium link cursor cursorpointer">'.img_picto($langs->trans("Reset"), 'eraser').'</span>';
				print '</td>';
				if (isModEnabled('stock')) {
					if (empty($conf->productbatch->enabled)) { // This check might need to be more nuanced if Product 483 has batches
						print '<td class="left">'.$langs->trans("Warehouse").' ('.$langs->trans("Stock").')</td>';
					} else {
						print '<td class="left">'.$langs->trans("Warehouse").' / '.$langs->trans("Batch").' ('.$langs->trans("Stock").')</td>';
					}
				}
				if (getDolGlobalString('SHIPPING_DISPLAY_STOCK_ENTRY_DATE')) {
					print '<td class="left">'.$langs->trans('StockEntryDate').'</td>';
				}
				print "</tr>\n";
			}

			$warehouse_id = GETPOSTINT('entrepot_id');
			$warehousePicking = array();
			// get all warehouse children for picking
			if ($warehouse_id > 0) {
				$warehousePicking[] = $warehouse_id;
				$warehouseObj = new Entrepot($db);
				$warehouseObj->get_children_warehouses($warehouse_id, $warehousePicking);
			}

			$indiceAsked = 0;
			while ($indiceAsked < $numAsked) {
				$product = new Product($db); // Instantiated for each line, good
				$line = $object->lines[$indiceAsked]; // This is the Sales Order line

                // Store original line properties for potential use, especially if MO line's fk_product was just updated.
                $original_line_description = $line->description;
                $original_line_fk_product_type = $line->product_type;
                $original_line_label = $line->label;

                // Consolidated MO line identification, MO ref extraction, and product ID determination for display/logic
                $is_mo_line = false;
                $target_mo_serial_ref = null;
                // Start with the actual fk_product from the line. This will be overridden to 483 if it's an MO line.
                $fk_product_to_use_for_display = $line->fk_product;

if (
    isset($line->description) &&
    (strpos($line->description, 'Costum-PC') === 0 || strpos($line->description, 'OF') === 0) &&
    strpos($line->description, '(Fabrication)') !== false
) {
    // Flag as manufacturing order line
    $is_mo_line = true;

    // Force display of product 483
    $fk_product_to_use_for_display = 483;

    // Extract the MO serial/ref (Costum-PCxxxÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ or OFxxxÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦)
    if (preg_match('/^(Costum-PC\S+|OF\S+)/', trim($line->description), $matches)) {
        $target_mo_serial_ref = $matches[1];
    } else {
        dol_syslog(
            "expedition/card.php (Display Loop): MO Line identified for Order Line ID: " 
            . $line->id 
            . ". Could not extract MO ref from description: '" 
            . $line->description 
            . "'. Expected pattern like 'Costum-PCxxxx-xxxxÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦' or 'OFxxxxxÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦'.",
            LOG_WARNING
        );
    }
}

                // else: Not an MO line based on description, $fk_product_to_use_for_display remains $line->fk_product (original value)

                // Calculate base_mo_ref_for_line for the current order line
                $base_mo_ref_for_line = '';
                if ($is_mo_line && $fk_product_to_use_for_display == 483 && isset($target_mo_serial_ref) && $target_mo_serial_ref !== null) {
                    if (function_exists('getBaseSerialNumberPart')) {
                        $base_mo_ref_for_line = getBaseSerialNumberPart($target_mo_serial_ref);
                    }
                }
                $original_line_fk_product_type = $line->product_type; // Use $line->product_type if available from fetch_lines()
                $original_line_label = $line->label;

                // Consolidated MO line identification and MO ref extraction
                $is_mo_line = false;
                $target_mo_serial_ref = null; 

                // Identify MO line based *solely* on description pattern now,
                // as fk_product would have been updated to 483 for MO lines in the preceding step (before this loop).
             if (
    isset($line->description) &&
    (strpos($line->description, 'Costum-PC') === 0 || strpos($line->description, 'OF') === 0) &&
    strpos($line->description, '(Fabrication)') !== false
) {
    $is_mo_line = true; // This line is an MO line

    // Extract the MO reference (serial number) from its description
    if (preg_match('/^(Costum-PC\S+|OF\S+)/', trim($line->description), $matches)) {
        $target_mo_serial_ref = $matches[1];
    } else {
        dol_syslog(
            "expedition/card.php (Display Loop): MO Line identified for Order Line ID: "
            . $line->id
            . ". Could not extract MO ref from description: '"
            . $line->description
            . "'. Expected pattern like 'Costum-PCxxxx-xxxx...' or 'OFxxxxx...'.",
            LOG_WARNING
        );
    }
}


                // Determine the product to use for display.
                $fk_product_to_use_for_display = $line->fk_product;

                // Calculate base_mo_ref_for_line for the current order line
                $base_mo_ref_for_line = ''; // Ensure it's reset for each $line
                if ($is_mo_line && $fk_product_to_use_for_display == 483 && !empty($target_mo_serial_ref)) { // Check !empty for $target_mo_serial_ref
                    if (function_exists('getBaseSerialNumberPart')) {
                        $base_mo_ref_for_line = getBaseSerialNumberPart($target_mo_serial_ref);
                    }
                }
                // If not, it's the original fk_product.
                $fk_product_to_use_for_display = $line->fk_product;
                // $mo_product_id_override = 483; // This is already implicitly handled if $line->fk_product is 483

				$parameters = array('i' => $indiceAsked, 'line' => $line, 'num' => $numAsked);
				$reshook = $hookmanager->executeHooks('printObjectLine', $parameters, $object, $action);
				if ($reshook < 0) {
					setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');
				}

				if (empty($reshook)) {
					// Show product and description
                    // The original code determined $type based on $line->product_type or $line->fk_product_type.
                    // For MO lines, $product->type (from product 483) will be more relevant if $fk_product_to_use_for_display > 0.
					$type = $line->product_type ? $line->product_type : $line->fk_product_type; // Original type determination
					if ($fk_product_to_use_for_display > 0 && isset($product->type)) { // If we fetched product 483
                        $type = $product->type; // Use product 483's type
                    } elseif ($is_mo_line) { // MO line but product 483 fetch failed (should be handled) or type not set
                        // Default to product type for MOs if product 483 info is incomplete
                        $type = Product::TYPE_PRODUCT; 
                    } else {
                        // Try to enhance type detection using date_start and date_end for free lines
                        if (!empty($line->date_start)) $type = Product::TYPE_SERVICE;
                        if (!empty($line->date_end)) $type = Product::TYPE_SERVICE;
                    }


					print '<!-- line for order line '.$line->id.' -->'."\n";
					print '<tr class="oddeven" id="row-'.$line->id.'">'."\n";

					// Product label
                    // Modified product label section:
                    if ($fk_product_to_use_for_display > 0) {  // If product is to be used (original or MO override)
                        $resFetchProdDisplay = $product->fetch($fk_product_to_use_for_display); // $product object now holds details of product 483 for MOs
                        if ($resFetchProdDisplay < 0) {
                            setEventMessages($product->error." Product ID: ".$fk_product_to_use_for_display, $product->errors, 'errors'); // More context
                            // Display minimal info or skip if product is critical
                            print '<td>Error fetching product ID: '.$fk_product_to_use_for_display.'</td>';
                        } else {
                            $product->load_stock('warehouseopen'); // Load stock for product 483 (or original product)

                            print '<td>'; // Start of the cell for product description
                            print '<a name="'.$line->id.'"></a>'; // Anchor with original sales order line ID
                            
                            $text_display_name = $product->getNomUrl(1); 

                            if (!$is_mo_line && !empty($original_line_label) && $original_line_label != $product->label) {
                                $text_display_name .= ' - ' . dol_escape_htmltag($original_line_label);
                            }
                        
                            $tooltip_content_for_line = $is_mo_line ? $original_line_description : $line->description;
                            print $form->textwithtooltip($text_display_name, dol_htmlentitiesbr($tooltip_content_for_line), 3, 0, '', $indiceAsked);

                            print_date_range($db->jdate($line->date_start), $db->jdate($line->date_end));

                            if (getDolGlobalString('PRODUIT_DESC_IN_FORM_ACCORDING_TO_DEVICE')) {
                                $supplemental_desc_to_show = $is_mo_line ? $original_line_description : $line->description;
                                if ($supplemental_desc_to_show && $supplemental_desc_to_show != $product->label) { 
                                    print '<br>'.dol_htmlentitiesbr($supplemental_desc_to_show);
                                }
                            }
                            print '</td>';
                        }
                    } else { 
                        // This 'else' is for TRUE free-text lines from sales order (fk_product was 0 AND it was NOT an MO).
                        print "<td>"; 
                        if ($original_line_fk_product_type == 1) { 
                            $text = img_object($langs->trans('Service'), 'service');
                        } else { 
                            $text = img_object($langs->trans('Product'), 'product');
                        }

                        if (!empty($original_line_label)) {
                            $text .= ' <strong>'.dol_escape_htmltag($original_line_label).'</strong>';
                            print $form->textwithtooltip($text, dol_htmlentitiesbr($original_line_description), 3, 0, '', $indiceAsked);
                        } else {
                            print $text.' '.nl2br(dol_htmlentitiesbr($original_line_description));
                        }

                        print_date_range($db->jdate($line->date_start), $db->jdate($line->date_end));
                        print "</td>\n";
                    }


					// unit of order
					$unit_order = '';
					if (getDolGlobalString('PRODUCT_USE_UNITS')) {
						$unit_order = measuringUnitString($line->fk_unit);
					}

					// Qty
					print '<td class="center">'.$line->qty;
					print '<input name="qtyasked'.$indiceAsked.'" id="qtyasked'.$indiceAsked.'" type="hidden" value="'.$line->qty.'">';
					print ''.$unit_order.'</td>';
					$qtyProdCom = $line->qty;

					// Qty already shipped
					print '<td class="center">';
					$quantityDelivered = isset($object->expeditions[$line->id]) ? (float) $object->expeditions[$line->id] : 0;
					print $quantityDelivered;
					print '<input name="qtydelivered'.$indiceAsked.'" id="qtydelivered'.$indiceAsked.'" type="hidden" value="'.$quantityDelivered.'">';
					print ''.$unit_order.'</td>';

					// Qty to ship
					$quantityAsked = (float) $line->qty;
                    // $type here should be correctly set for Product 483 if it's an MO line.
					if ($type == Product::TYPE_SERVICE && !getDolGlobalString('STOCK_SUPPORTS_SERVICES') && !getDolGlobalString('SHIPMENT_SUPPORTS_SERVICES')) {
						$quantityToBeDelivered = 0;
					} else {
						if (is_numeric($quantityDelivered)) {
							$quantityToBeDelivered = $quantityAsked - $quantityDelivered;
						} else {
							$quantityToBeDelivered = $quantityAsked;
						}
					}

					$warehouseObject = null;
                    // The condition `!($line->fk_product > 0)` needs to be `!($fk_product_to_use_for_display > 0)` for MO lines
					if (count($warehousePicking) == 1 || !($fk_product_to_use_for_display > 0) || !isModEnabled('stock')) {     // If warehouse was already selected or if product is not a predefined, we go into this part with no multiwarehouse selection
						print '<!-- Case warehouse already known or product not a predefined product -->';
						//ship from preselected location
                        // $product->stock_warehouse comes from product 483 for MO lines
						$stock = + (isset($product->stock_warehouse[$warehouse_id]->real) ? $product->stock_warehouse[$warehouse_id]->real : 0); // Convert to number
						if ($type == Product::TYPE_SERVICE && getDolGlobalString('SHIPMENT_SUPPORTS_SERVICES')) { // $type is from Prod 483 for MO
							$deliverableQty = $quantityToBeDelivered;
						} else {
							$deliverableQty = min($quantityToBeDelivered, $stock);
						}
						if ($deliverableQty < 0) {
							$deliverableQty = 0;
						}
                        // $product->hasbatch() comes from product 483 for MO lines
						if (empty($conf->productbatch->enabled) || !$product->hasbatch()) {
							// Standard product, no batch management
							print '<td class="center">';
							if ($type == Product::TYPE_PRODUCT || getDolGlobalString('STOCK_SUPPORTS_SERVICES') || ($type == Product::TYPE_SERVICE && getDolGlobalString('SHIPMENT_SUPPORTS_SERVICES'))) {
								$input_readonly = ($quantityAsked == $quantityDelivered) ? ' readonly="readonly"' : '';
								$final_deliverable_qty = ($quantityAsked == $quantityDelivered) ? 0 : $deliverableQty;
								print '<input name="idl'.$indiceAsked.'" type="hidden" value="'.$line->id.'">';
								print '<input name="qtyl'.$indiceAsked.'" id="qtyl'.$indiceAsked.'" class="qtyl right" type="text" size="4" value="'.$final_deliverable_qty.'"'.$input_readonly.'>';
							} else {
								if (getDolGlobalString('SHIPMENT_GETS_ALL_ORDER_PRODUCTS')) print '<input name="idl'.$indiceAsked.'" type="hidden" value="'.$line->id.'"><input name="qtyl'.$indiceAsked.'" id="qtyl'.$indiceAsked.'" type="hidden" value="0">';
								print $langs->trans("NA");
							}
							print '</td>';

							if (isModEnabled('stock')) {
								print '<td class="left">';
								if ($type == Product::TYPE_PRODUCT || getDolGlobalString('STOCK_SUPPORTS_SERVICES')) {
									if ($fk_product_to_use_for_display > 0) {
										$tmpentrepot_id = is_numeric(GETPOST("entl".$indiceAsked)) ? GETPOSTINT("entl".$indiceAsked) : $warehouse_id;
										print $formproduct->selectWarehouses($tmpentrepot_id, 'entl'.$indiceAsked, '', 1, 0, $fk_product_to_use_for_display, '', 1, 0, array(), 'minwidth200', array(), 1, (getDolGlobalInt('STOCK_ALLOW_NEGATIVE_TRANSFER') ? false : 0), 'stock DESC, e.ref');
										if ($tmpentrepot_id > 0 && $tmpentrepot_id == $warehouse_id && $stock < $quantityToBeDelivered) print ' '.img_warning($langs->trans("StockTooLow"));
									}
								} else {
									print '<span class="opacitymedium">('.$langs->trans("Service").')</span><input name="entl'.$indiceAsked.'" id="entl'.$indiceAsked.'" type="hidden" value="0">';
								}
								print '</td>';
							}
							if (getDolGlobalString('SHIPPING_DISPLAY_STOCK_ENTRY_DATE')) print '<td></td>';
							print "</tr>\n";

							if (getDolGlobalString('PRODUIT_SOUSPRODUITS') && $fk_product_to_use_for_display > 0) {
								// Sub-product display logic remains unchanged
							}
						} else { // Product needs lot/serial
							print '<input name="idl'.$indiceAsked.'" type="hidden" value="'.$line->id.'">';
							print '<td></td>'; // Empty cell for Qty (moved to subline)
							if (isModEnabled('stock')) print '<td></td>'; // Empty cell for Warehouse (moved to subline)
							if (getDolGlobalString('SHIPPING_DISPLAY_STOCK_ENTRY_DATE')) print '<td></td>';
							print '</tr>';

							if ($product->status_batch == 2) { // Product is managed by unique serial numbers
								$qty_to_ship = $quantityAsked - $quantityDelivered;
								if ($qty_to_ship > 0) {
									for ($j = 0; $j < $qty_to_ship; $j++) {
										$subj = $j;
										print '<tr class="oddeven"><td colspan="3"></td>';
										print '<td class="center">'; // Qty input
										print '<input class="qtyl right" name="qtyl'.$indiceAsked.'_'.$subj.'" type="text" size="4" value="1" readonly="readonly">';
										print '</td>';
										print '<td class="left">'; // Batch (serial) Text Input
										if ($warehouse_id > 0 && $warehousestatic->id != $warehouse_id) $warehousestatic->fetch($warehouse_id);
										if (!empty($warehousestatic->id)) print $warehousestatic->getNomUrl(0).' / ';
										print '<input type="text" class="maxwidth150" name="batch_text_l'.$indiceAsked.'_'.$subj.'" value="">';
										print '<input type="hidden" name="entl'.$indiceAsked.'_'.$subj.'" value="'.$warehouse_id.'">';
										print '</td>';
										if (getDolGlobalString('SHIPPING_DISPLAY_STOCK_ENTRY_DATE')) print '<td></td>';
										print '</tr>';
									}
								}
							} else { // Product is managed by batches
								$subj = 0; // Assuming one manual entry line per order line
								print '<tr class="oddeven"><td colspan="3"></td>';
								print '<td class="center">'; // Qty input
								$qty_to_propose = $quantityToBeDelivered;
								$input_readonly_batch = ($quantityAsked == $quantityDelivered) ? ' readonly="readonly"' : '';
								$final_qty_batch = ($quantityAsked == $quantityDelivered) ? 0 : $qty_to_propose;
								print '<input class="qtyl right" name="qtyl'.$indiceAsked.'_'.$subj.'" type="text" size="4" value="'.($final_qty_batch > 0 ? $final_qty_batch : 0).'"'.$input_readonly_batch.'>';
								print '</td>';

								print '<td class="left">'; // Batch Text Input
								if ($warehouse_id > 0 && $warehousestatic->id != $warehouse_id) $warehousestatic->fetch($warehouse_id);
								if (!empty($warehousestatic->id)) print $warehousestatic->getNomUrl(0).' / ';

								print '<input type="text" class="maxwidth150" name="batch_text_l'.$indiceAsked.'_'.$subj.'" value="">';
								print '<input type="hidden" name="entl'.$indiceAsked.'_'.$subj.'" value="'.$warehouse_id.'">';
								print '</td>';
								if (getDolGlobalString('SHIPPING_DISPLAY_STOCK_ENTRY_DATE')) print '<td></td>';
								print '</tr>';
							}
						}
					} else { // Multi-warehouse logic for batch products
						if (empty($conf->productbatch->enabled) || !$product->hasbatch()) {
							// This logic remains largely the same as it's for non-batch products in multi-WH scenario
							print '<!-- Case warehouse not already known and product does not need lot -->';
							print '<td></td><td></td>';
							if (getDolGlobalString('SHIPPING_DISPLAY_STOCK_ENTRY_DATE')) print '<td></td>';
							print '</tr>'."\n";
							// ... (original logic for multi-warehouse non-batch products)
						} else { // Product needs lot/serial
							print '<input name="idl'.$indiceAsked.'" type="hidden" value="'.$line->id.'">';
							print '<td></td>'; // Empty cell for Qty (moved to subline)
							if (isModEnabled('stock')) print '<td></td>'; // Empty cell for Warehouse (moved to subline)
							if (getDolGlobalString('SHIPPING_DISPLAY_STOCK_ENTRY_DATE')) print '<td></td>';
							print '</tr>';

							if ($product->status_batch == 2) { // Product is managed by unique serial numbers
								$qty_to_ship = $quantityAsked - $quantityDelivered;
								if ($qty_to_ship > 0) {
									for ($j = 0; $j < $qty_to_ship; $j++) {
										$subj = $j;
										print '<tr class="oddeven"><td colspan="3"></td>';
										print '<td class="center">'; // Qty input
										print '<input class="qtyl right" name="qtyl'.$indiceAsked.'_'.$subj.'" type="text" size="4" value="1" readonly="readonly">';
										print '</td>';
										print '<td class="left">'; // Batch (serial) Text Input
										if ($warehouse_id > 0 && $warehousestatic->id != $warehouse_id) $warehousestatic->fetch($warehouse_id);
										if (!empty($warehousestatic->id)) print $warehousestatic->getNomUrl(0).' / ';
										print '<input type="text" class="maxwidth150" name="batch_text_l'.$indiceAsked.'_'.$subj.'" value="">';
										print '<input type="hidden" name="entl'.$indiceAsked.'_'.$subj.'" value="'.$warehouse_id.'">';
										print '</td>';
										if (getDolGlobalString('SHIPPING_DISPLAY_STOCK_ENTRY_DATE')) print '<td></td>';
										print '</tr>';
									}
								}
							} else { // Product is managed by batches
								$subj = 0; // Assuming one manual entry line per order line
								print '<tr class="oddeven"><td colspan="3"></td>';
								print '<td class="center">'; // Qty input
								$qty_to_propose = $quantityToBeDelivered;
								$input_readonly_batch = ($quantityAsked == $quantityDelivered) ? ' readonly="readonly"' : '';
								$final_qty_batch = ($quantityAsked == $quantityDelivered) ? 0 : $qty_to_propose;
								print '<input class="qtyl right" name="qtyl'.$indiceAsked.'_'.$subj.'" type="text" size="4" value="'.($final_qty_batch > 0 ? $final_qty_batch : 0).'"'.$input_readonly_batch.'>';
								print '</td>';

								print '<td class="left">'; // Batch Text Input
								if ($warehouse_id > 0 && $warehousestatic->id != $warehouse_id) $warehousestatic->fetch($warehouse_id);
								if (!empty($warehousestatic->id)) print $warehousestatic->getNomUrl(0).' / ';

								print '<input type="text" class="maxwidth150" name="batch_text_l'.$indiceAsked.'_'.$subj.'" value="">';
								print '<input type="hidden" name="entl'.$indiceAsked.'_'.$subj.'" value="'.$warehouse_id.'">';
								print '</td>';
								if (getDolGlobalString('SHIPPING_DISPLAY_STOCK_ENTRY_DATE')) print '<td></td>';
								print '</tr>';
							}
						}
					}

					// Extrafields display logic remains unchanged
					if (!empty($extrafields)) {
						$colspan = 5;
						$expLine = new ExpeditionLigne($db);
						$srcLine = new OrderLine($db);
						$srcLine->id = $line->id;
						$srcLine->fetch_optionals();
						$expLine->array_options = array_merge($expLine->array_options, $srcLine->array_options);
						print $expLine->showOptionals($extrafields, 'edit', array('style' => 'class="drag drop oddeven"', 'colspan' => $colspan), $indiceAsked, '', 1);
					}
				}

				$indiceAsked++;
			}

			print "</table>";
			print '</div>';

			print '<br>';

			print $form->buttonsSaveCancel("Create");

			print '</form>';

			print '<br>';
		} else {
			dol_print_error($db);
		}
	}
} elseif ($object->id > 0) {
	'@phan-var-force Expedition $object';  // Need to force it (type overridden earlier)

	// Edit and view mode

	$lines = $object->lines;

	$num_prod = count($lines);

	if (!empty($object->origin) && $object->origin_id > 0) {
		$typeobject = $object->origin;
		$origin = $object->origin;
		$origin_id = $object->origin_id;

		$object->fetch_origin(); // Load property $object->origin_object (old $object->commande, $object->propal, ...)
	}

	$soc = new Societe($db);
	$soc->fetch($object->socid);

	$res = $object->fetch_optionals();

	$head = shipping_prepare_head($object);
	print dol_get_fiche_head($head, 'shipping', $langs->trans("Shipment"), -1, $object->picto);

	$formconfirm = '';

	// Confirm deletion
	if ($action == 'delete') {
		$formquestion = array();
		if ($object->status == Expedition::STATUS_CLOSED && getDolGlobalString('STOCK_CALCULATE_ON_SHIPMENT_CLOSE')) {
			$formquestion = array(
					array(
						'label' => $langs->trans('ShipmentIncrementStockOnDelete'),
						'name' => 'alsoUpdateStock',
						'type' => 'checkbox',
						'value' => 0
					),
				);
		}
		$formconfirm = $form->formconfirm(
			$_SERVER['PHP_SELF'].'?id='.$object->id,
			$langs->trans('DeleteSending'),
			$langs->trans("ConfirmDeleteSending", $object->ref),
			'confirm_delete',
			$formquestion,
			0,
			1
		);
	}

	// Confirmation validation
	if ($action == 'valid') {
		$objectref = substr($object->ref, 1, 4);
		if ($objectref == 'PROV') {
			$numref = $object->getNextNumRef($soc);
		} else {
			$numref = $object->ref;
		}

		$text = $langs->trans("ConfirmValidateSending", $numref);
		if (getDolGlobalString('STOCK_CALCULATE_ON_SHIPMENT')) {
			$text .= '<br>'.img_picto('', 'movement', 'class="pictofixedwidth"').$langs->trans("StockMovementWillBeRecorded").'.';
		} elseif (getDolGlobalString('STOCK_CALCULATE_ON_SHIPMENT_CLOSE')) {
			$text .= '<br>'.img_picto('', 'movement', 'class="pictofixedwidth"').$langs->trans("StockMovementNotYetRecorded").'.';
		}

		if (isModEnabled('notification')) {
			require_once DOL_DOCUMENT_ROOT.'/core/class/notify.class.php';
			$notify = new Notify($db);
			$text .= '<br>';
			$text .= $notify->confirmMessage('SHIPPING_VALIDATE', $object->socid, $object);
		}

		$formconfirm = $form->formconfirm($_SERVER['PHP_SELF'].'?id='.$object->id, $langs->trans('ValidateSending'), $text, 'confirm_valid', '', 0, 1, 250);
	}
	// Confirm cancellation
	if ($action == 'cancel') {
		$formconfirm = $form->formconfirm($_SERVER['PHP_SELF'].'?id='.$object->id, $langs->trans('CancelSending'), $langs->trans("ConfirmCancelSending", $object->ref), 'confirm_cancel', '', 0, 1);
	}

	// Call Hook formConfirm
	$parameters = array('formConfirm' => $formconfirm);
	$reshook = $hookmanager->executeHooks('formConfirm', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
	if (empty($reshook)) {
		$formconfirm .= $hookmanager->resPrint;
	} elseif ($reshook > 0) {
		$formconfirm = $hookmanager->resPrint;
	}

	// Print form confirm
	print $formconfirm;

	// Calculate totalWeight and totalVolume for all products
	// by adding weight and volume of each product line.
	$tmparray = $object->getTotalWeightVolume();
	$totalWeight = $tmparray['weight'];
	$totalVolume = $tmparray['volume'];

	if (!empty($typeobject) && $typeobject === 'commande' && is_object($object->origin_object) && $object->origin_object->id && isModEnabled('order')) {
		$objectsrc = new Commande($db);
		$objectsrc->fetch($object->origin_object->id);
	}
	if (!empty($typeobject) && $typeobject === 'propal' && is_object($object->origin_object) && $object->origin_object->id && isModEnabled("propal")) {
		$objectsrc = new Propal($db);
		$objectsrc->fetch($object->origin_object->id);
	}

	// Shipment card
	$linkback = '<a href="'.DOL_URL_ROOT.'/expedition/list.php?restore_lastsearch_values=1'.(!empty($socid) ? '&socid='.$socid : '').'">'.$langs->trans("BackToList").'</a>';
	$morehtmlref = '<div class="refidno">';
	// Ref customer shipment
	$morehtmlref .= $form->editfieldkey("RefCustomer", 'ref_customer', $object->ref_customer, $object, $user->hasRight('expedition', 'creer'), 'string', '', 0, 1);
	$morehtmlref .= $form->editfieldval("RefCustomer", 'ref_customer', $object->ref_customer, $object, $user->hasRight('expedition', 'creer'), 'string'.(isset($conf->global->THIRDPARTY_REF_INPUT_SIZE) ? ':' . getDolGlobalString('THIRDPARTY_REF_INPUT_SIZE') : ''), '', null, null, '', 1);
	// Thirdparty
	$morehtmlref .= '<br>'.$object->thirdparty->getNomUrl(1);
	// Project
	if (isModEnabled('project')) {
		$langs->load("projects");
		$morehtmlref .= '<br>';
		if (0) {	// Do not change on shipment
			$morehtmlref .= img_picto($langs->trans("Project"), 'project', 'class="pictofixedwidth"');
			if ($action != 'classify') {
				$morehtmlref .= '<a class="editfielda" href="'.$_SERVER['PHP_SELF'].'?action=classify&token='.newToken().'&id='.$object->id.'">'.img_edit($langs->transnoentitiesnoconv('SetProject')).'</a> ';
			}
			$morehtmlref .= $form->form_project($_SERVER['PHP_SELF'].'?id='.$object->id, $objectsrc->socid, $objectsrc->fk_project, ($action == 'classify' ? 'projectid' : 'none'), 0, 0, 0, 1, '', 'maxwidth300');
		} else {
			if (!empty($objectsrc) && !empty($objectsrc->fk_project)) {
				$proj = new Project($db);
				$proj->fetch($objectsrc->fk_project);
				$morehtmlref .= $proj->getNomUrl(1);
				if ($proj->title) {
					$morehtmlref .= '<span class="opacitymedium"> - '.dol_escape_htmltag($proj->title).'</span>';
				}
			}
		}
	}
	$morehtmlref .= '</div>';


	dol_banner_tab($object, 'ref', $linkback, 1, 'ref', 'ref', $morehtmlref);


	print '<div class="fichecenter">';
	print '<div class="fichehalfleft">';
	print '<div class="underbanner clearboth"></div>';

	print '<table class="border tableforfield centpercent">';

	// Linked documents
	if (!empty($typeobject) && $typeobject == 'commande' && $object->origin_object->id && isModEnabled('order')) {
		print '<tr><td>';
		print $langs->trans("RefOrder").'</td>';
		print '<td>';
		print $objectsrc->getNomUrl(1, 'commande');
		print "</td>\n";
		print '</tr>';
	}
	if (!empty($typeobject) && $typeobject == 'propal' && $object->origin_object->id && isModEnabled("propal")) {
		print '<tr><td>';
		print $langs->trans("RefProposal").'</td>';
		print '<td>';
		print $objectsrc->getNomUrl(1, 'expedition');
		print "</td>\n";
		print '</tr>';
	}

	// Date creation
	print '<tr><td class="titlefieldmiddle">'.$langs->trans("DateCreation").'</td>';
	print '<td>'.dol_print_date($object->date_creation, "dayhour")."</td>\n";
	print '</tr>';

	// Delivery date planned
	print '<tr><td height="10">';
	print '<table class="nobordernopadding centpercent"><tr><td>';
	print $langs->trans('DateDeliveryPlanned');
	print '</td>';
	if ($action != 'editdate_livraison') {
		print '<td class="right"><a class="editfielda" href="'.$_SERVER["PHP_SELF"].'?action=editdate_livraison&token='.newToken().'&id='.$object->id.'">'.img_edit($langs->trans('SetDeliveryDate'), 1).'</a></td>';
	}
	print '</tr></table>';
	print '</td><td>';
	if ($action == 'editdate_livraison') {
		print '<form name="setdate_livraison" action="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'" method="post">';
		print '<input type="hidden" name="token" value="'.newToken().'">';
		print '<input type="hidden" name="action" value="setdate_livraison">';
		print $form->selectDate($object->date_delivery ? $object->date_delivery : -1, 'liv_', 1, 1, 0, "setdate_livraison", 1, 0);
		print '<input type="submit" class="button button-edit smallpaddingimp" value="'.$langs->trans('Modify').'">';
		print '</form>';
	} else {
		print $object->date_delivery ? dol_print_date($object->date_delivery, 'dayhour') : '&nbsp;';
	}
	print '</td>';
	print '</tr>';

	// Delivery sending date
	print '<tr><td height="10">';
	print '<table class="nobordernopadding centpercent"><tr><td>';
	print $langs->trans('DateShipping');
	print '</td>';
	if ($action != 'editdate_shipping') {
		print '<td class="right"><a class="editfielda" href="'.$_SERVER["PHP_SELF"].'?action=editdate_shipping&token='.newToken().'&id='.$object->id.'">'.img_edit($langs->trans('SetShippingDate'), 1).'</a></td>';
	}
	print '</tr></table>';
	print '</td><td>';
	if ($action == 'editdate_shipping') {
		print '<form name="setdate_shipping" action="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'" method="post">';
		print '<input type="hidden" name="token" value="'.newToken().'">';
		print '<input type="hidden" name="action" value="setdate_shipping">';
		print $form->selectDate($object->date_shipping ? $object->date_shipping : -1, 'ship_', 1, 1, 0, "setdate_shipping", 1, 0);
		print '<input type="submit" class="button button-edit smallpaddingimp" value="'.$langs->trans('Modify').'">';
		print '</form>';
	} else {
		print $object->date_shipping ? dol_print_date($object->date_shipping, 'dayhour') : '&nbsp;';
	}
	print '</td>';
	print '</tr>';

	// Weight
	print '<tr><td>';
	print $form->editfieldkey("Weight", 'trueWeight', $object->trueWeight, $object, $user->hasRight('expedition', 'creer'));
	print '</td><td>';

	if ($action == 'edittrueWeight') {
		print '<form name="settrueweight" action="'.$_SERVER["PHP_SELF"].'" method="post">';
		print '<input name="action" value="settrueWeight" type="hidden">';
		print '<input name="id" value="'.$object->id.'" type="hidden">';
		print '<input type="hidden" name="token" value="'.newToken().'">';
		print '<input id="trueWeight" name="trueWeight" value="'.$object->trueWeight.'" type="text" class="width50 valignmiddle">';
		print $formproduct->selectMeasuringUnits("weight_units", "weight", $object->weight_units, 0, 2, 'maxwidth125 valignmiddle');
		print ' <input class="button smallpaddingimp valignmiddle" name="modify" value="'.$langs->trans("Modify").'" type="submit">';
		print ' <input class="button button-cancel smallpaddingimp valignmiddle" name="cancel" value="'.$langs->trans("Cancel").'" type="submit">';
		print '</form>';
	} else {
		print $object->trueWeight;
		print ($object->trueWeight && $object->weight_units != '') ? ' '.measuringUnitString(0, "weight", $object->weight_units) : '';
	}

	// Calculated
	if ($totalWeight > 0) {
		if (!empty($object->trueWeight)) {
			print ' ('.$langs->trans("SumOfProductWeights").': ';
		}
		print showDimensionInBestUnit($totalWeight, 0, "weight", $langs, getDolGlobalInt('MAIN_WEIGHT_DEFAULT_ROUND', -1), isset($conf->global->MAIN_WEIGHT_DEFAULT_UNIT) ? $conf->global->MAIN_WEIGHT_DEFAULT_UNIT : 'no');
		if (!empty($object->trueWeight)) {
			print ')';
		}
	}
	print '</td></tr>';

	// Width
	print '<tr><td>'.$form->editfieldkey("Width", 'trueWidth', $object->trueWidth, $object, $user->hasRight('expedition', 'creer')).'</td><td>';
	print $form->editfieldval("Width", 'trueWidth', $object->trueWidth, $object, $user->hasRight('expedition', 'creer'));
	print ($object->trueWidth && $object->width_units != '') ? ' '.measuringUnitString(0, "size", $object->width_units) : '';
	print '</td></tr>';

	// Height
	print '<tr><td>'.$form->editfieldkey("Height", 'trueHeight', $object->trueHeight, $object, $user->hasRight('expedition', 'creer')).'</td><td>';
	if ($action == 'edittrueHeight') {
		print '<form name="settrueHeight" action="'.$_SERVER["PHP_SELF"].'" method="post">';
		print '<input name="action" value="settrueHeight" type="hidden">';
		print '<input name="id" value="'.$object->id.'" type="hidden">';
		print '<input type="hidden" name="token" value="'.newToken().'">';
		print '<input id="trueHeight" name="trueHeight" value="'.$object->trueHeight.'" type="text" class="width50">';
		print $formproduct->selectMeasuringUnits("size_units", "size", $object->size_units, 0, 2);
		print ' <input class="button smallpaddingimp" name="modify" value="'.$langs->trans("Modify").'" type="submit">';
		print ' <input class="button button-cancel smallpaddingimp" name="cancel" value="'.$langs->trans("Cancel").'" type="submit">';
		print '</form>';
	} else {
		print $object->trueHeight;
		print ($object->trueHeight && $object->height_units != '') ? ' '.measuringUnitString(0, "size", $object->height_units) : '';
	}

	print '</td></tr>';

	// Depth
	print '<tr><td>'.$form->editfieldkey("Depth", 'trueDepth', $object->trueDepth, $object, $user->hasRight('expedition', 'creer')).'</td><td>';
	print $form->editfieldval("Depth", 'trueDepth', $object->trueDepth, $object, $user->hasRight('expedition', 'creer'));
	print ($object->trueDepth && $object->depth_units != '') ? ' '.measuringUnitString(0, "size", $object->depth_units) : '';
	print '</td></tr>';

	// Volume
	print '<tr><td>';
	print $langs->trans("Volume");
	print '</td>';
	print '<td>';
	$calculatedVolume = 0;
	$volumeUnit = 0;
	if ($object->trueWidth && $object->trueHeight && $object->trueDepth) {
		$calculatedVolume = ($object->trueWidth * $object->trueHeight * $object->trueDepth);
		$volumeUnit = $object->size_units * 3;
	}
	// If sending volume not defined we use sum of products
	if ($calculatedVolume > 0) {
		if ($volumeUnit < 50) {
			print showDimensionInBestUnit($calculatedVolume, $volumeUnit, "volume", $langs, getDolGlobalInt('MAIN_VOLUME_DEFAULT_ROUND', -1), getDolGlobalString('MAIN_VOLUME_DEFAULT_UNIT', 'no'));
		} else {
			print $calculatedVolume.' '.measuringUnitString(0, "volume", (string) $volumeUnit);
		}
	}
	if ($totalVolume > 0) {
		if ($calculatedVolume) {
			print ' ('.$langs->trans("SumOfProductVolumes").': ';
		}
		print showDimensionInBestUnit($totalVolume, 0, "volume", $langs, getDolGlobalInt('MAIN_VOLUME_DEFAULT_ROUND', -1), getDolGlobalString('MAIN_VOLUME_DEFAULT_UNIT', 'no'));
		//if (empty($calculatedVolume)) print ' ('.$langs->trans("Calculated").')';
		if ($calculatedVolume) {
			print ')';
		}
	}
	print "</td>\n";
	print '</tr>';

	// Other attributes
	//$cols = 2;
	include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_view.tpl.php';

	print '</table>';

	print '</div>';
	print '<div class="fichehalfright">';
	print '<div class="underbanner clearboth"></div>';

	print '<table class="border centpercent tableforfield">';

	// Sending method
	print '<tr><td>';
	print '<table class="nobordernopadding centpercent"><tr><td>';
	print $langs->trans('SendingMethod');
	print '</td>';

	if ($action != 'editshipping_method_id' && $permissiontoadd) {
		print '<td class="right"><a class="editfielda" href="'.$_SERVER["PHP_SELF"].'?action=editshipping_method_id&token='.newToken().'&id='.$object->id.'">'.img_edit($langs->trans('SetSendingMethod'), 1).'</a></td>';
	}
	print '</tr></table>';
	print '</td><td>';
	if ($action == 'editshipping_method_id') {
		print '<form name="setshipping_method_id" action="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'" method="post">';
		print '<input type="hidden" name="token" value="'.newToken().'">';
		print '<input type="hidden" name="action" value="setshipping_method_id">';
		$object->fetch_delivery_methods();
		print $form->selectarray("shipping_method_id", $object->meths, $object->shipping_method_id, 1, 0, 0, "", 1);
		if ($user->admin) {
			print info_admin($langs->trans("YouCanChangeValuesForThisListFromDictionarySetup"), 1);
		}
		print '<input type="submit" class="button button-edit smallpaddingimp" value="'.$langs->trans('Modify').'">';
		print '</form>';
	} else {
		if ($object->shipping_method_id > 0) {
			// Get code using getLabelFromKey
			$code = $langs->getLabelFromKey($db, $object->shipping_method_id, 'c_shipment_mode', 'rowid', 'code');
			print $langs->trans("SendingMethod".strtoupper($code));
		}
	}
	print '</td>';
	print '</tr>';

	// Tracking Number
	print '<tr><td class="titlefieldmiddle">'.$form->editfieldkey("TrackingNumber", 'tracking_number', $object->tracking_number, $object, $user->hasRight('expedition', 'creer')).'</td><td>';
	print $form->editfieldval("TrackingNumber", 'tracking_number', $object->tracking_url, $object, $user->hasRight('expedition', 'creer'), 'safehtmlstring', $object->tracking_number);
	print '</td></tr>';

	// Incoterms
	if (isModEnabled('incoterm')) {
		print '<tr><td>';
		print '<table class="nobordernopadding centpercent"><tr><td>';
		print $langs->trans('IncotermLabel');
		print '<td><td class="right">';
		if ($permissiontoadd) {
			print '<a class="editfielda" href="'.DOL_URL_ROOT.'/expedition/card.php?id='.$object->id.'&action=editincoterm&token='.newToken().'">'.img_edit().'</a>';
		} else {
			print '&nbsp;';
		}
		print '</td></tr></table>';
		print '</td>';
		print '<td>';
		if ($action != 'editincoterm') {
			print $form->textwithpicto($object->display_incoterms(), $object->label_incoterms, 1);
		} else {
			print $form->select_incoterms((!empty($object->fk_incoterms) ? $object->fk_incoterms : ''), (!empty($object->location_incoterms) ? $object->location_incoterms : ''), $_SERVER['PHP_SELF'].'?id='.$object->id);
		}
		print '</td></tr>';
	}

	// Other attributes
	$parameters = array();
	$reshook = $hookmanager->executeHooks('formObjectOptions', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
	print $hookmanager->resPrint;

	print "</table>";

	print '</div>';
	print '</div>';

	print '<div class="clearboth"></div>';


	// Lines of products

	if ($action == 'editline') {
		print '	<form name="updateline" id="updateline" action="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&amp;lineid='.$line_id.'" method="POST">
		<input type="hidden" name="token" value="' . newToken().'">
		<input type="hidden" name="action" value="updateline">
		<input type="hidden" name="mode" value="">
		<input type="hidden" name="id" value="' . $object->id.'">
		';
	}
	print '<br>';

	print '<div class="div-table-responsive-no-min">';
	print '<table class="noborder centpercent" id="tablelines" >';
	print '<thead>';
	print '<tr class="liste_titre">';
	// Adds a line numbering column
	if (getDolGlobalString('MAIN_VIEW_LINE_NUMBER')) {
		print '<td width="5" class="center linecolnum">&nbsp;</td>';
	}
	// Product/Service
	print '<td  class="linecoldescription" >'.$langs->trans("Products").'</td>';
	// Qty
	print '<td class="center linecolqty">'.$langs->trans("QtyOrdered").'</td>';
	if ($origin && $origin_id > 0) {
		print '<td class="center linecolqtyinothershipments">'.$langs->trans("QtyInOtherShipments").'</td>';
	}
	if ($action == 'editline') {
		$editColspan = 3;
		if (!isModEnabled('stock')) {
			$editColspan--;
		}
		if (empty($conf->productbatch->enabled)) {
			$editColspan--;
		}
		print '<td class="center linecoleditlineotherinfo" colspan="'.$editColspan.'">';
		if ($object->status <= 1) {
			print $langs->trans("QtyToShip");
		} else {
			print $langs->trans("QtyShipped");
		}
		if (isModEnabled('stock')) {
			print ' - '.$langs->trans("WarehouseSource");
		}
		if (isModEnabled('productbatch')) {
			print ' - '.$langs->trans("Batch");
		}
		print '</td>';
	} else {
		if ($object->status <= 1) {
			print '<td class="center linecolqtytoship">'.$langs->trans("QtyToShip").'</td>';
		} else {
			print '<td class="center linecolqtyshipped">'.$langs->trans("QtyShipped").'</td>';
		}
		if (isModEnabled('stock')) {
			print '<td class="left linecolwarehousesource">'.$langs->trans("WarehouseSource").'</td>';
		}

		if (isModEnabled('productbatch')) {
			print '<td class="left linecolbatch">'.$langs->trans("Batch").'</td>';
		}
	}
	print '<td class="center linecolweight">'.$langs->trans("CalculatedWeight").'</td>';
	print '<td class="center linecolvolume">'.$langs->trans("CalculatedVolume").'</td>';
	//print '<td class="center">'.$langs->trans("Size").'</td>';
	if ($object->status == 0) {
		print '<td class="linecoledit"></td>';
		print '<td class="linecoldelete" width="10"></td>';
	}
	print "</tr>\n";
	print '</thead>';

	$outputlangs = $langs;

	if (getDolGlobalInt('MAIN_MULTILANGS') && getDolGlobalString('PRODUIT_TEXTS_IN_THIRDPARTY_LANGUAGE')) {
		$object->fetch_thirdparty();
		$newlang = '';
		if (empty($newlang) && GETPOST('lang_id', 'aZ09')) {
			$newlang = GETPOST('lang_id', 'aZ09');
		}
		if (empty($newlang)) {
			$newlang = $object->thirdparty->default_lang;
		}
		if (!empty($newlang)) {
			$outputlangs = new Translate("", $conf);
			$outputlangs->setDefaultLang($newlang);
		}
	}

	// Get list of products already sent for same source object into $alreadysent
	$alreadysent = array();
	if ($origin && $origin_id > 0) {
		$sql = "SELECT obj.rowid, obj.fk_product, obj.label, obj.description, obj.product_type as fk_product_type, obj.qty as qty_asked, obj.fk_unit, obj.date_start, obj.date_end";
		$sql .= ", ed.rowid as shipmentline_id, ed.qty as qty_shipped, ed.fk_expedition as expedition_id, ed.fk_elementdet, ed.fk_entrepot";
		$sql .= ", e.rowid as shipment_id, e.ref as shipment_ref, e.date_creation, e.date_valid, e.date_delivery, e.date_expedition";
		//if (getDolGlobalInt('MAIN_SUBMODULE_DELIVERY')) $sql .= ", l.rowid as livraison_id, l.ref as livraison_ref, l.date_delivery, ld.qty as qty_received";
		$sql .= ', p.label as product_label, p.ref, p.fk_product_type, p.rowid as prodid, p.tosell as product_tosell, p.tobuy as product_tobuy, p.tobatch as product_tobatch';
		$sql .= ', p.description as product_desc';
		$sql .= " FROM ".MAIN_DB_PREFIX."expeditiondet as ed";
		$sql .= ", ".MAIN_DB_PREFIX."expedition as e";
		$sql .= ", ".MAIN_DB_PREFIX.$origin."det as obj";
		//if (getDolGlobalInt('MAIN_SUBMODULE_DELIVERY')) $sql .= " LEFT JOIN ".MAIN_DB_PREFIX."delivery as l ON l.fk_expedition = e.rowid LEFT JOIN ".MAIN_DB_PREFIX."deliverydet as ld ON ld.fk_delivery = l.rowid  AND obj.rowid = ld.fk_origin_line";
		$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."product as p ON obj.fk_product = p.rowid";
		$sql .= " WHERE e.entity IN (".getEntity('expedition').")";
		$sql .= " AND obj.fk_".$origin." = ".((int) $origin_id);
		$sql .= " AND obj.rowid = ed.fk_elementdet";
		$sql .= " AND ed.fk_expedition = e.rowid";
		//if ($filter) $sql.= $filter;
		$sql .= " ORDER BY obj.fk_product";

		dol_syslog("expedition/card.php get list of shipment lines", LOG_DEBUG);
		$resql = $db->query($sql);
		if ($resql) {
			$num = $db->num_rows($resql);
			$i = 0;

			while ($i < $num) {
				$obj = $db->fetch_object($resql);
				if ($obj) {
					// $obj->rowid is rowid in $origin."det" table
					$alreadysent[$obj->rowid][$obj->shipmentline_id] = array(
						'shipment_ref' => $obj->shipment_ref, 'shipment_id' => $obj->shipment_id, 'warehouse' => $obj->fk_entrepot, 'qty_shipped' => $obj->qty_shipped,
						'product_tosell' => $obj->product_tosell, 'product_tobuy' => $obj->product_tobuy, 'product_tobatch' => $obj->product_tobatch,
						'date_valid' => $db->jdate($obj->date_valid), 'date_delivery' => $db->jdate($obj->date_delivery));
				}
				$i++;
			}
		}
		//var_dump($alreadysent);
	}

	print '<tbody>';

	// Loop on each product to send/sent
	for ($i = 0; $i < $num_prod; $i++) {
		$parameters = array('i' => $i, 'line' => $lines[$i], 'line_id' => $line_id, 'num' => $num_prod, 'alreadysent' => $alreadysent, 'editColspan' => !empty($editColspan) ? $editColspan : 0, 'outputlangs' => $outputlangs);
		$reshook = $hookmanager->executeHooks('printObjectLine', $parameters, $object, $action);
		if ($reshook < 0) {
			setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');
		}

		if (empty($reshook)) {
			print '<!-- origin line id = '.$lines[$i]->origin_line_id.' -->'; // id of order line
			print '<tr class="oddeven" id="row-'.$lines[$i]->id.'" data-id="'.$lines[$i]->id.'" data-element="'.$lines[$i]->element.'" >';

			// #
			if (getDolGlobalString('MAIN_VIEW_LINE_NUMBER')) {
				print '<td class="center linecolnum">'.($i + 1).'</td>';
			}

			// Predefined product or service
			if ($lines[$i]->fk_product > 0) {
				// Define output language
				if (getDolGlobalInt('MAIN_MULTILANGS') && getDolGlobalString('PRODUIT_TEXTS_IN_THIRDPARTY_LANGUAGE')) {
					$prod = new Product($db);
					$prod->fetch($lines[$i]->fk_product);
					$label = (!empty($prod->multilangs[$outputlangs->defaultlang]["label"])) ? $prod->multilangs[$outputlangs->defaultlang]["label"] : $lines[$i]->product_label;
				} else {
					$label = (!empty($lines[$i]->label) ? $lines[$i]->label : $lines[$i]->product_label);
				}

				print '<td class="linecoldescription">';

				// Show product and description
				$product_static->type = $lines[$i]->fk_product_type;
				$product_static->id = $lines[$i]->fk_product;
				$product_static->ref = $lines[$i]->ref;
				$product_static->status = $lines[$i]->product_tosell;
				$product_static->status_buy = $lines[$i]->product_tobuy;
				$product_static->status_batch = $lines[$i]->product_tobatch;

				$product_static->weight = $lines[$i]->weight;
				$product_static->weight_units = $lines[$i]->weight_units;
				$product_static->length = $lines[$i]->length;
				$product_static->length_units = $lines[$i]->length_units;
				$product_static->width = !empty($lines[$i]->width) ? $lines[$i]->width : 0;
				$product_static->width_units = !empty($lines[$i]->width_units) ? $lines[$i]->width_units : 0;
				$product_static->height = !empty($lines[$i]->height) ? $lines[$i]->height : 0;
				$product_static->height_units = !empty($lines[$i]->height_units) ? $lines[$i]->height_units : 0;
				$product_static->surface = $lines[$i]->surface;
				$product_static->surface_units = $lines[$i]->surface_units;
				$product_static->volume = $lines[$i]->volume;
				$product_static->volume_units = $lines[$i]->volume_units;

				$text = $product_static->getNomUrl(1);
				$text .= ' - '.$label;
				$description = (getDolGlobalInt('PRODUIT_DESC_IN_FORM_ACCORDING_TO_DEVICE') ? '' : dol_htmlentitiesbr($lines[$i]->description));
				print $form->textwithtooltip($text, $description, 3, 0, '', $i);
				print_date_range(!empty($lines[$i]->date_start) ? $lines[$i]->date_start : '', !empty($lines[$i]->date_end) ? $lines[$i]->date_end : '');
				if (getDolGlobalInt('PRODUIT_DESC_IN_FORM_ACCORDING_TO_DEVICE')) {
					print (!empty($lines[$i]->description) && $lines[$i]->description != $lines[$i]->product) ? '<br>'.dol_htmlentitiesbr($lines[$i]->description) : '';
				}
				print "</td>\n";
			} else {
				print '<td class="linecoldescription" >';
				if ($lines[$i]->product_type == Product::TYPE_SERVICE) {
					$text = img_object($langs->trans('Service'), 'service');
				} else {
					$text = img_object($langs->trans('Product'), 'product');
				}

				if (!empty($lines[$i]->label)) {
					$text .= ' <strong>'.$lines[$i]->label.'</strong>';
					print $form->textwithtooltip($text, $lines[$i]->description, 3, 0, '', $i);
				} else {
					print $text.' '.nl2br($lines[$i]->description);
				}

				print_date_range($lines[$i]->date_start, $lines[$i]->date_end);
				print "</td>\n";
			}

			$unit_order = '';
			if (getDolGlobalString('PRODUCT_USE_UNITS')) {
				$unit_order = measuringUnitString($lines[$i]->fk_unit);
			}

			// Qty ordered
			print '<td class="center linecolqty">'.$lines[$i]->qty_asked.' '.$unit_order.'</td>';

			// Qty in other shipments (with shipment and warehouse used)
			if ($origin && $origin_id > 0) {
				print '<td class="linecolqtyinothershipments center nowrap">';
				$htmltooltip = '';
				$qtyalreadysent = 0;
				foreach ($alreadysent as $key => $val) {
					if ($lines[$i]->fk_elementdet == $key) {
						$j = 0;
						foreach ($val as $shipmentline_id => $shipmentline_var) {
							if ($shipmentline_var['shipment_id'] == $lines[$i]->fk_expedition) {
								continue; // We want to show only "other shipments"
							}

							$j++;
							if ($j > 1) {
								$htmltooltip .= '<br>';
							}
							$shipment_static->fetch($shipmentline_var['shipment_id']);
							$htmltooltip .= $shipment_static->getNomUrl(1, '', 0, 0, 1);
							$htmltooltip .= ' - '.$shipmentline_var['qty_shipped'];
							$htmltooltip .= ' - '.$langs->trans("DateValidation").' : '.(empty($shipmentline_var['date_valid']) ? $langs->trans("Draft") : dol_print_date($shipmentline_var['date_valid'], 'dayhour'));
							/*if (isModEnabled('stock') && $shipmentline_var['warehouse'] > 0) {
								$warehousestatic->fetch($shipmentline_var['warehouse']);
								$htmltext .= '<br>'.$langs->trans("FromLocation").' : '.$warehousestatic->getNomUrl(1, '', 0, 1);
							}*/
							//print ' '.$form->textwithpicto('', $htmltext, 1);

							$qtyalreadysent += $shipmentline_var['qty_shipped'];
						}
						if ($j) {
							$htmltooltip = $langs->trans("QtyInOtherShipments").'...<br><br>'.$htmltooltip.'<br><input type="submit" name="dummyhiddenbuttontogetfocus" style="display:none" autofocus>';
						}
					}
				}
				print $form->textwithpicto($qtyalreadysent, $htmltooltip, 1, 'info', '', 0, 3, 'tooltip'.$lines[$i]->id);
				print '</td>';
			}

			if ($action == 'editline' && $lines[$i]->id == $line_id) {
				// edit mode
				print '<td colspan="'.$editColspan.'" class="center"><table class="nobordernopadding centpercent">';
				if (is_array($lines[$i]->detail_batch) && count($lines[$i]->detail_batch) > 0) {
							// Edit lines for existing batches
					foreach ($lines[$i]->detail_batch as $detail_batch) {
						print '<tr>';
								// Qty
								$is_serial_edit = ($lines[$i]->product_tobatch == 2);
								$qty_input_attrs_edit = $is_serial_edit ? ' value="1" readonly="readonly"' : ' value="'.dol_escape_htmltag($detail_batch->qty).'"';
								print '<td><input class="qtyl right" name="qtyl'.$detail_batch->fk_expeditiondet.'_'.$detail_batch->id.'" type="text" size="4"'.$qty_input_attrs_edit.'></td>';
								// Warehouse and Batch
								print '<td>';
								$entrepot_id = !empty($detail_batch->entrepot_id) ? $detail_batch->entrepot_id : $lines[$i]->entrepot_id;
								print $formproduct->selectWarehouses($entrepot_id, 'entl'.$detail_batch->fk_expeditiondet.'_'.$detail_batch->id, '', 1, 0, $lines[$i]->fk_product);
								print ' / ';
								print '<input type="text" class="maxwidth150" name="batch_text_l'.$detail_batch->fk_expeditiondet.'_'.$detail_batch->id.'" value="'.dol_escape_htmltag($detail_batch->batch).'">';
								print '</td>';
						print '</tr>';
					}
							// Line to add a new batch
					print '<tr>';
							print '<td><input class="qtyl" name="qtyl'.$line_id.'_0" type="text" size="4" value="0"></td>';
							print '<td>';
							print $formproduct->selectWarehouses('', 'entl'.$line_id.'_0', '', 1, 0, $lines[$i]->fk_product);
							print ' / ';
							print '<input type="text" class="maxwidth150" name="batch_text_l'.$line_id.'_0" value="">';
							print '</td>';
							print '</tr>';
						} else { // Standard product line editing
							print '<tr>';
							print '<td><input class="qtyl right" name="qtyl'.$line_id.'" id="qtyl'.$line_id.'" type="text" size="4" value="'.$lines[$i]->qty_shipped.'">'.$unit_order.'</td>';
							if (isModEnabled('stock')) {
								print '<td>';
								if ($lines[$i]->fk_product > 0) {
									print $formproduct->selectWarehouses($lines[$i]->entrepot_id, 'entl'.$line_id, '', 1, 0, $lines[$i]->fk_product, '', 1, 0, array(), 'minwidth200');
								} else {
									print '<span class="opacitymedium">('.$langs->trans("Service").')</span>';
								}
								print '</td>';
					}
							if (isModEnabled('productbatch')) print '<td> - </td>';
					print '</tr>';
				}
				print '</table></td>';
			} else {
						// VIEW MODE
				print '<td class="linecolqtytoship center">'.$lines[$i]->qty_shipped.' '.$unit_order.'</td>';

				if (isModEnabled('stock')) {
					print '<td class="linecolwarehousesource tdoverflowmax200">';
					if ($lines[$i]->product_type == Product::TYPE_SERVICE && getDolGlobalString('SHIPMENT_SUPPORTS_SERVICES')) {
						print '<span class="opacitymedium">('.$langs->trans("Service").')</span>';
					} elseif ($lines[$i]->entrepot_id > 0) {
						$entrepot = new Entrepot($db);
						$entrepot->fetch($lines[$i]->entrepot_id);
						print $entrepot->getNomUrl(1);
					} elseif (count($lines[$i]->details_entrepot) > 1) {
						$detail = '';
						foreach ($lines[$i]->details_entrepot as $detail_entrepot) {
							if ($detail_entrepot->entrepot_id > 0) {
								$entrepot = new Entrepot($db);
								$entrepot->fetch($detail_entrepot->entrepot_id);
								$detail .= $langs->trans("DetailWarehouseFormat", $entrepot->label, $detail_entrepot->qty_shipped).'<br>';
							}
						}
						print $form->textwithtooltip(img_picto('', 'object_stock').' '.$langs->trans("DetailWarehouseNumber"), $detail);
					}
					print '</td>';
				}

				if (isModEnabled('productbatch')) {
							print '<td class="linecolbatch">';
							if ($lines[$i]->product_tobatch && isset($lines[$i]->detail_batch)) {
								$detail = '';
								foreach ($lines[$i]->detail_batch as $dbatch) {
									$detail .= $langs->trans("Batch").': '.dol_escape_htmltag($dbatch->batch).' - '.$langs->trans("Qty").': '.$dbatch->qty.'<br>';
						}
								print $form->textwithtooltip(img_picto('', 'object_barcode').' '.$langs->trans("DetailBatchNumber"), $detail);
					} else {
								print '&nbsp;';
					}
							print '</td>';
				}
			}

			// Weight
			print '<td class="center linecolweight">';
			if ($lines[$i]->fk_product_type == Product::TYPE_PRODUCT) {
				print $lines[$i]->weight * $lines[$i]->qty_shipped.' '.measuringUnitString(0, "weight", $lines[$i]->weight_units);
			} else {
				print '&nbsp;';
			}
			print '</td>';

			// Volume
			print '<td class="center linecolvolume">';
			if ($lines[$i]->fk_product_type == Product::TYPE_PRODUCT) {
				print $lines[$i]->volume * $lines[$i]->qty_shipped.' '.measuringUnitString(0, "volume", $lines[$i]->volume_units);
			} else {
				print '&nbsp;';
			}
			print '</td>';

			// Size
			//print '<td class="center">'.$lines[$i]->volume*$lines[$i]->qty_shipped.' '.measuringUnitString(0, "volume", $lines[$i]->volume_units).'</td>';

			if ($action == 'editline' && $lines[$i]->id == $line_id) {
				print '<td class="center" colspan="2" valign="middle">';
				print '<input type="submit" class="button button-save" id="savelinebutton marginbottomonly" name="save" value="'.$langs->trans("Save").'"><br>';
				print '<input type="submit" class="button button-cancel" id="cancellinebutton" name="cancel" value="'.$langs->trans("Cancel").'"><br>';
				print '</td>';
			} elseif ($object->status == Expedition::STATUS_DRAFT) {
				// edit-delete buttons
				print '<td class="linecoledit center">';
				print '<a class="editfielda reposition" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=editline&token='.newToken().'&lineid='.$lines[$i]->id.'">'.img_edit().'</a>';
				print '</td>';
				print '<td class="linecoldelete" width="10">';
				print '<a class="reposition" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=deleteline&token='.newToken().'&lineid='.$lines[$i]->id.'">'.img_delete().'</a>';
				print '</td>';

				// Display lines extrafields
				if (!empty($rowExtrafieldsStart)) {
					print $rowExtrafieldsStart;
					print $rowExtrafieldsView;
					print $rowEnd;
				}
			}
			print "</tr>";

			// Display lines extrafields.
			// $line is a line of shipment
			if (!empty($extrafields)) {
				$colspan = 6;
				if ($origin && $origin_id > 0) {
					$colspan++;
				}
				if (isModEnabled('productbatch')) {
					$colspan++;
				}
				if (isModEnabled('stock')) {
					$colspan++;
				}

				$line = $lines[$i];
				$line->fetch_optionals();

				// TODO Show all in same line by setting $display_type = 'line'
				if ($action == 'editline' && $line->id == $line_id) {
					print $lines[$i]->showOptionals($extrafields, 'edit', array('colspan' => $colspan), !empty($indiceAsked) ? $indiceAsked : '', '', 0, 'card');
				} else {
					print $lines[$i]->showOptionals($extrafields, 'view', array('colspan' => $colspan), !empty($indiceAsked) ? $indiceAsked : '', '', 0, 'card');
				}
			}
		}
	}

	// TODO Show also lines ordered but not delivered

	if (empty($num_prod)) {
		print '<tr><td colspan="8"><span class="opacitymedium">'.$langs->trans("NoLineGoOnTabToAddSome", $langs->transnoentitiesnoconv("ShipmentDistribution")).'</span></td></tr>';
	}

	print "</table>\n";
	print '</tbody>';
	print '</div>';


	print dol_get_fiche_end();


	$object->fetchObjectLinked($object->id, $object->element);




// Check if the user meets all criteria to be allowed to cancel
$userCanCancel = false;

// 1. Check if user is in the correct group (ID 16)
$sql_check_group = "SELECT COUNT(*) as count FROM ".MAIN_DB_PREFIX."usergroup_user WHERE fk_user = ".((int) $user->id)." AND fk_usergroup = 16";
$resql_check_group = $db->query($sql_check_group);
if ($resql_check_group) {
    $obj_group = $db->fetch_object($resql_check_group);
    if ($obj_group && $obj_group->count > 0) {
        // User is in the group. Now check the warehouse condition.
        $warehouseCheckPassed = false;
        
        // 2. Check user's warehouse. If NULL, the check passes automatically.
        if (is_null($user->fk_warehouse) || empty($user->fk_warehouse)) {
            $warehouseCheckPassed = true;
        } else {
            // User has a default warehouse. All products in the shipment must come from it.
            $allLinesMatch = true;
            if (!empty($object->lines) && is_array($object->lines)) {
                foreach ($object->lines as $line) {
                    // Skip warehouse check for non-products (services)
                    if ($line->fk_product_type != 0) { // 0 = Product::TYPE_PRODUCT
                        continue;
                    }
                    
                    // Check if the line's warehouse matches the user's warehouse
                    if ($line->entrepot_id != $user->fk_warehouse) {
                        $allLinesMatch = false;
                        break; // A mismatch was found, no need to check further.
                    }
                }
            }
            if ($allLinesMatch) {
                $warehouseCheckPassed = true;
            }
        }
        
        // 3. If both group and warehouse checks passed, the user can cancel.
        if ($warehouseCheckPassed) {
            $userCanCancel = true;
        }
    }
}


	/*
	 *    Boutons actions
	 */

	if (($user->socid == 0) && ($action != 'presend')) {
		print '<div class="tabsAction">';

		$parameters = array();
		$reshook = $hookmanager->executeHooks('addMoreActionsButtons', $parameters, $object, $action); // Note that $action and $object may have been
		// modified by hook
		if (empty($reshook)) {
			if ($object->status == Expedition::STATUS_DRAFT && $num_prod > 0) {
				if ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('expedition', 'creer'))
				 || (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('expedition', 'shipping_advance', 'validate'))) {
					print dolGetButtonAction('', $langs->trans('Validate'), 'default', $_SERVER["PHP_SELF"].'?action=valid&token='.newToken().'&id='.$object->id, '');
				} else {
					print dolGetButtonAction($langs->trans('NotAllowed'), $langs->trans('Validate'), 'default', $_SERVER['PHP_SELF']. '#', '', false);
				}
			}

			// 0=draft, 1=validated/delivered, 2=closed/delivered
			if ($object->status == Expedition::STATUS_VALIDATED && !getDolGlobalString('STOCK_CALCULATE_ON_SHIPMENT')) {
				if ($user->hasRight('expedition', 'creer')) {
					print dolGetButtonAction('', $langs->trans('SetToDraft'), 'default', $_SERVER["PHP_SELF"].'?action=setdraft&token='.newToken().'&id='.$object->id, '');
				}
			}
			if ($object->status == Expedition::STATUS_CLOSED) {
				if ($user->hasRight('expedition', 'creer')) {
					if ($user->admin) {
						print dolGetButtonAction('', $langs->trans('ReOpen'), 'default', $_SERVER["PHP_SELF"].'?action=reopen&token='.newToken().'&id='.$object->id, '');
					}
				}
			}

			// Send
			if (empty($user->socid)) {
				if ($object->status > 0) {
					if (!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') || $user->hasRight('expedition', 'shipping_advance', 'send')) {
						print dolGetButtonAction('', $langs->trans('SendMail'), 'default', $_SERVER["PHP_SELF"].'?action=presend&token='.newToken().'&id='.$object->id.'&mode=init#formmailbeforetitle', '');
					} else {
						print dolGetButtonAction('', $langs->trans('SendMail'), 'default', $_SERVER['PHP_SELF']. '#', '', false);
					}
				}
			}

			// Create bill
			if (isModEnabled('invoice') && ($object->status == Expedition::STATUS_VALIDATED || $object->status == Expedition::STATUS_CLOSED)) {
if ($user->hasRight('facture', 'creer') && $user->admin) {
					if (getDolGlobalString('WORKFLOW_BILL_ON_SHIPMENT') !== '0') {
						print dolGetButtonAction('', $langs->trans('CreateBill'), 'default', DOL_URL_ROOT.'/compta/facture/card.php?action=create&origin='.$object->element.'&originid='.$object->id.'&socid='.$object->socid, '');
					}
				}
			}

			// This is just to generate a delivery receipt
			//var_dump($object->linkedObjectsIds['delivery']);
			if (getDolGlobalInt('MAIN_SUBMODULE_DELIVERY') && ($object->status == Expedition::STATUS_VALIDATED || $object->status == Expedition::STATUS_CLOSED) && $user->hasRight('expedition', 'delivery', 'creer') && empty($object->linkedObjectsIds['delivery'])) {
				print dolGetButtonAction('', $langs->trans('CreateDeliveryOrder'), 'default', $_SERVER["PHP_SELF"].'?action=create_delivery&token='.newToken().'&id='.$object->id, '');
			}

			// Set Billed and Closed
if ($user->hasRight('expedition', 'creer') && $object->status > 0) {
				if ($user->hasRight('expedition', 'creer') && $object->status > 0) {
					if (!$object->billed && getDolGlobalString('WORKFLOW_BILL_ON_SHIPMENT') !== '0') {
						if ($user->admin) {
							print dolGetButtonAction('', $langs->trans('ClassifyBilled'), 'default', $_SERVER["PHP_SELF"].'?action=classifybilled&token='.newToken().'&id='.$object->id, '');
						}
					}
					print dolGetButtonAction('', $langs->trans("Close"), 'default', $_SERVER["PHP_SELF"].'?action=classifyclosed&token='.newToken().'&id='.$object->id, '');
				}
			}

			// Cancel
	
// Cancel
if ($object->status == Expedition::STATUS_VALIDATED) {
    // Show Cancel button only if user has permission and meets the custom group/warehouse rules
    if ($user->hasRight('expedition', 'creer') && $userCanCancel) {
        print dolGetButtonAction('', $langs->trans('Cancel'), 'danger', $_SERVER["PHP_SELF"].'?action=cancel&token='.newToken().'&id='.$object->id.'&mode=init#formmailbeforetitle', '');
    }
}


			// Delete
			if ($user->hasRight('expedition', 'supprimer')) {
				print dolGetButtonAction('', $langs->trans('Delete'), 'delete', $_SERVER["PHP_SELF"].'?action=delete&token='.newToken().'&id='.$object->id, '');
			}
		}

		print '</div>';
	}


	/*
	 * Documents generated
	 */

	if ($action != 'presend' && $action != 'editline') {
		print '<div class="fichecenter"><div class="fichehalfleft">';

		$objectref = dol_sanitizeFileName($object->ref);
		$filedir = $conf->expedition->dir_output."/sending/".$objectref;

		$urlsource = $_SERVER["PHP_SELF"]."?id=".$object->id;

		$genallowed = $user->hasRight('expedition', 'lire');
		$delallowed = $user->hasRight('expedition', 'creer');

		print $formfile->showdocuments('expedition', $objectref, $filedir, $urlsource, $genallowed, $delallowed, $object->model_pdf, 1, 0, 0, 28, 0, '', '', '', $soc->default_lang);


		// Show links to link elements
		$tmparray = $form->showLinkToObjectBlock($object, array(), array('shipping'), 1);
		$linktoelem = $tmparray['linktoelem'];
		$htmltoenteralink = $tmparray['htmltoenteralink'];
		print $htmltoenteralink;

		$somethingshown = $form->showLinkedObjectBlock($object, $linktoelem);

		// Show online signature link
		$useonlinesignature = getDolGlobalInt('EXPEDITION_ALLOW_ONLINESIGN');

		if ($object->statut != Expedition::STATUS_DRAFT && $useonlinesignature) {
			print '<br><!-- Link to sign -->';
			require_once DOL_DOCUMENT_ROOT.'/core/lib/signature.lib.php';
			print showOnlineSignatureUrl('expedition', $object->ref, $object).'<br>';
		}

		print '</div><div class="fichehalfright">';

		// List of actions on element
		include_once DOL_DOCUMENT_ROOT.'/core/class/html.formactions.class.php';
		$formactions = new FormActions($db);
		$somethingshown = $formactions->showactions($object, 'shipping', $socid, 1);

		print '</div></div>';
	}


	/*
	 * Action presend
	 */

	//Select mail models is same action as presend
	if (GETPOST('modelselected')) {
		$action = 'presend';
	}

	// Presend form
	$modelmail = 'shipping_send';
	$defaulttopic = 'SendShippingRef';
	$diroutput = $conf->expedition->dir_output.'/sending';
	$trackid = 'shi'.$object->id;

	include DOL_DOCUMENT_ROOT.'/core/tpl/card_presend.tpl.php';
}

// End of page
// Your custom JS code to enable/disable MO serial inputs and handle quantities
// End of page
// Your custom JS code to enable/disable MO serial inputs and handle quantities
print '<script type="text/javascript">
$(document).ready(function() {
    // Enforce readonly + zero on fully shipped lines
    $("input[name^=\'qtyasked\']").each(function() {
        var $qtyAsked = $(this);
        var name = $qtyAsked.attr("name");
        var idxMatch = name.match(/qtyasked(\d+)/);
        if (!idxMatch) return;
        var idx = idxMatch[1];
        var asked = parseFloat($qtyAsked.val()) || 0;
        var delivered = parseFloat($("input[name=\'qtydelivered" + idx + "\']").val()) || 0;
        if (asked <= delivered) {
            // main line
            $("input[name=\'qtyl" + idx + "\']").val(0).prop("readonly", true);
            // sub‑lines
            $("input[name^=\'qtyl" + idx + "_\']").each(function() {
                $(this).val(0).prop("readonly", true);
            });
        }
    });
});
</script>';
llxFooter();
$db->close();
