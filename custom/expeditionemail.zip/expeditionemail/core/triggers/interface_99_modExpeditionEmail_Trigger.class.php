<?php
// Trigger pour envoi automatique d'e-mail après validation d'une expédition

include_once DOL_DOCUMENT_ROOT .'/core/class/interfaces/interfaceTrigger.class.php';
include_once DOL_DOCUMENT_ROOT . '/core/class/CMailFile.class.php';

class InterfaceExpeditionEmailTrigger extends InterfaceTrigger
{
    public function __construct()
    {
        global $langs;
        $this->name = 'ExpeditionEmailTrigger';
        $this->description = 'Trigger to send email automatically after expedition validation';
        $this->version = 'dolibarr'; 
        $this->picto = 'email';
    }

    public function runTrigger($action, $object, $user, $langs, $conf)
    {
        if (($action === 'SHIPPING_VALIDATE' || $action === 'DELIVERY_VALIDATE') && !empty($object->id)) {

            dol_syslog("Trigger ExpeditionEmail: Trigger for action $action");

            // Générer le PDF
            $object->generateDocument('espadon', $langs);
            $file = $conf->expedition->dir_output.'/sending/'.$object->ref.'/'.$object->ref.'.pdf';

            if (!file_exists($file)) {
                dol_syslog("Trigger ExpeditionEmail: PDF file not found ($file)", LOG_WARNING);
                return -1;
            }

            // Email du client
            $to = $object->thirdparty->email;
            $toname = $object->thirdparty->name;

            if (empty($to)) {
                dol_syslog("Trigger ExpeditionEmail: No email found for thirdparty", LOG_WARNING);
                return -1;
            }

            // Préparer l'email
            $subject = '['.$conf->global->MAIN_INFO_SOCIETE_NOM.'] '.$langs->trans("DeliveryFollow").' #'.$object->ref;
            $message = "Bonjour $toname,\n\nVotre expédition ".$object->ref." a été validée. Veuillez trouver le bon d'expédition en pièce jointe.\n\nMerci.";

            $mail = new CMailFile(
                $subject,
                $to,
                $conf->global->MAIN_MAIL_EMAIL_FROM,
                $message,
                array($file),
                array(), // cc
                array(), // bcc
                '',
                '',
                0 // texte
            );

            if (!$mail->sendfile()) {
                dol_syslog("Trigger ExpeditionEmail: Mail send failed: ".$mail->error, LOG_ERR);
                return -1;
            }

            dol_syslog("Trigger ExpeditionEmail: Mail sent to $to");
            return 1;
        }

        return 0;
    }
}
