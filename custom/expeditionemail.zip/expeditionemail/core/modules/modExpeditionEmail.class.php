<?php
include_once DOL_DOCUMENT_ROOT .'/core/modules/DolibarrModules.class.php';

class modExpeditionEmail extends DolibarrModules
{
    public function __construct($db)
    {
        parent::__construct($db);
        $this->numero = 105000;
        $this->family = "financial";
        $this->name = "expeditionemail";
        $this->description = "Send PDF by mail after shipment validation";
        $this->version = '1.0';
        $this->const_name = 'MAIN_MODULE_EXPEDITIONEMAIL';
        $this->picto = 'shipping';
        $this->dirs = array();
        $this->module_parts = array(
            'triggers' => 1
        );
        $this->rights = array();
        $this->dictionaries = array();
    }
}
