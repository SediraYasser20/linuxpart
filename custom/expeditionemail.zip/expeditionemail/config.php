<?php

// Permet d’inclure automatiquement le descripteur si besoin
dol_include_once('/expeditionemail/core/modules/modExpeditionEmail.class.php');

